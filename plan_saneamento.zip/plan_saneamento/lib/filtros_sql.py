
from .util.wrapper_qgis import *
from qgis.utils import iface
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from .util.con_bd import *


def lee_capa_unsafe(cadea):
    cap=QgsProject.instance().mapLayersByName(cadea)
    len_cap=len(cap)

    if len_cap>1:
        raise ExcepcionCapas("{} ------- Duplicada no TOC".format(cadea))
    else:
        if len_cap < 1 :
            return False
    QgsMessageLog.logMessage("{} ------- Filtrada".format(cadea), str_nome_proc, level=Qgis.Success)
    return cap[0]


FILTRO_EDAR="""
(uuid in ( 
	select fkedaruuid
	from datos_psg.conexnucleoedar 
	where fkuuidnucleo in (
		select uuid 
		from datos_psg.nucleosps 
		where fkmunicod = {}
	)
) 

or 

ST_Intersects(
(select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),
geom)
) AND ("int_borra"  = 0 or "int_borra"  is null )
"""
FILTRO_CONEXIONES="""
"fkuuidnucleo" in (
select uuid 
from datos_psg.nucleosps
where fkmunicod={}
) AND fkedaruuid not in ( 
    (select uuid from datos_psg.edarps where  int_borra =1)
) AND ("int_borra"  != 1 or "int_borra"  is null )
"""
FILTRO_BUFFER="""
ST_Intersects(
(select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),
geom) 
"""
FILTRO_CONTORNO="""
ST_Intersects(
(select geom from datos_psg.munips where codmuni={}),
geom) AND ("int_borra"  = 0 or "int_borra"  is null )
"""

FILTRO_STR_COD="fkmunicod={}"

FILTRO_FOCAIS="""
("subtipofa" != 36 OR "subtipofa" IS NULL) 
AND 
(ST_Intersects(
(select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),
geom))
"""
FILTRO_FOTOS_EDAR= """
uuidedar in (
	select uuid 
	from datos_psg.edarps 
	where st_intersects( 
        (select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),geom
	)
)
"""
FILTRO_FOTOS_BOMBEO="""
fkbombuuid in (
	select uuid 
	from datos_psg.bombps 
	where st_intersects( 
        (select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),geom
	)
)
"""
FILTRO_FOTOS_TTORM="""
fkttormuuid in (
	select uuid 
	from datos_psg.ttormps 
	where st_intersects( 
        (select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),geom
	)
)
"""
FILTRO_SPATIALITE_PUNTOS="""
ST_Intersects(
	(select geometry from munips where codmuni = {}), geometry
)
"""

FILTRO_PVERTPS="""
ST_Intersects(
(select st_union(st_buffer(geom,2000)) from datos_psg.munips where codmuni={}),
geom)  AND ("titular"  NOT  LIKE 'persona física' or titular is null)
"""

FILTRO_PCV="""
"cod_tarefa_base" = {} 
and "orixe" not in ('Aportes Naturais','Augas naturais','Pluviais','Pluviais sen contaminación','Residuos','Terra-Obras')
and "natureza" not in ('Augas Pluviais','Terras-Obras','Vivendas-Particular','Pluviais con tratamento','Non Existe Vertido')
and {}
"""

def format_result(cur_res):
    i=0
    cadea=''
    if len(cur_res)>1:
        cadea=cadea+'IN ('
        for f in cur_res:
            if i != 0:
                cadea=cadea+','
            cadea=cadea+"\'"+ f[0]+"\'"
            i=i+1
        cadea=cadea+')'
    elif len(cur_res) == 1:
        cadea=cadea+'='
        cadea=cadea+"\'"+cur_res[0][0]+"\'"
    return cadea

def query_bd(base_str):
    conn= ConnBD()
    cur=conn.get_cursor()
    cur.execute(base_str)
    res=cur.fetchall()
    if not res:
        return
    conn.pecha()
    res= format_result(res)
    return res


def maxpol(geom):
    xeom=None
    i=0
    area=0
    for x in geom.asGeometryCollection():
        if i == 0:
            xeom= x
        if x.area()>area:
            area=x.area()
            xeom=x
    return xeom
            

class ReferenciasCapas:
    capas_buffer=['bombps', 'ttormps','emisps']
    capas_codigo=["nucleosps",'parroquiasps']
    capa_conexions="conexnucleoedar"
    capas_contorno=["aglomps","munipsfotos",'polindps','colps']
    capas_spatialite=["eiel_edar","eiel_emisarios","eiel_pvert","eiel_colectores","pcv_autorizados_urb","riosps"]
    # capa_filtro_str='filtro'
    capa_municipio_str='munips'
    capa_siotuga_str='siotuga'

    def __init__(self) -> None:
        # self.capas=capas_qgis(ReferenciasCapas.capas_str) 
        self.capas_codigo=capas_qgis(ReferenciasCapas.capas_codigo)
        self.capas_contorno=capas_qgis(ReferenciasCapas.capas_contorno)
        self.capas_spatialite=capas_qgis(ReferenciasCapas.capas_spatialite)
        self.capas_buffer=capas_qgis(ReferenciasCapas.capas_buffer)
        self.codmuni=None 
        self.conexions=lee_capa(ReferenciasCapas.capa_conexions)
        # self.filtro_capa=lee_capa(ReferenciasCapas.capa_filtro_str)
        self.municipio_capa=lee_capa(ReferenciasCapas.capa_municipio_str)
        capa_atlas=lee_capa_unsafe('ATLAS')
        self.siotuga=lee_capa_unsafe(ReferenciasCapas.capa_siotuga_str)
        if capa_atlas:
            self.capas_spatialite.append(capa_atlas)
    
    def filtra_capas(self,codigo):
        self.filtro_edar(codigo)
        self.filtro_controno(codigo)
        self.filtro_spatialite(codigo)
        self.filtro_codigo(codigo)
        self.filtro_buffer(codigo)
        self.filtro_conexions(codigo)
        self.filtro_focais(codigo)
        self.filtro_pvert(codigo)
        self.filtro_fotos(codigo)
        self.filtro_pcv(codigo)
        self.fitro_as(codigo)
        if self.siotuga:
            self.filtro_siotuga(codigo)
        
    def filtro_siotuga(self,codigo):
        filt=FILTRO_SPATIALITE_PUNTOS.format(codigo)
        ff=filt+' and "cla_homo" not like \'SR\''
        self.siotuga.setSubsetString(ff)

    def filtro_pvert(self,codigo):
        filt=FILTRO_PVERTPS.format(codigo)
        capa_pver=lee_capa("pvertps")
        capa_pver.setSubsetString(filt)
    def filtro_focais(self,codigo):
        filt=FILTRO_FOCAIS.format(codigo)
        capa_focais=lee_capa('focaiscontps')
        capa_focais.setSubsetString(filt)
    def filtro_conexions(self,codigo):
        flt=FILTRO_CONEXIONES.format(codigo)
        self.conexions.setSubsetString(flt)
    def filtro_buffer(self,codigo):
        filt=FILTRO_BUFFER.format(codigo)
        for c in self.capas_buffer:
            c.setSubsetString(filt)
    def filtro_edar(self,codigo):
        capa_edar=lee_capa('edarps')
        str_f_bd=FILTRO_EDAR.format(codigo,codigo)
        capa_edar.setSubsetString(str_f_bd)

    def filtro_spatialite(self,cod):
        filt=FILTRO_SPATIALITE_PUNTOS.format(cod)
        for c in self.capas_spatialite:
            c.setSubsetString(filt)
    def filtro_codigo(self,cod):
        flt=FILTRO_STR_COD.format(cod)
        for c in self.capas_codigo:
            c.setSubsetString(flt)

    def filtro_controno(self,cod):
        st=FILTRO_CONTORNO.format(cod)
        for c in self.capas_contorno:
            c.setSubsetString(st)
    def filtro_fotos(self,codigo):
        fotos_dar=lee_capa('edarpsfotos')
        fotos_tt=lee_capa('ttormpsfotos')
        fotosbomb=lee_capa('bombpsfotos')
        str_bomb=FILTRO_FOTOS_BOMBEO.format(codigo)
        str_eda=FILTRO_FOTOS_EDAR.format(codigo)
        str_ttorm=FILTRO_FOTOS_TTORM.format(codigo)
        fotos_dar.setSubsetString(str_eda)
        fotos_tt.setSubsetString(str_ttorm)
        fotosbomb.setSubsetString(str_bomb)
    def fitro_as(self,codigo):
        pass
        # vert= lee_capa_unsafe('asv_vertidos')
        # aut=lee_capa_unsafe('asv_datos_autorizacion')
        # sanc=lee_capa_unsafe('asv_datos_sancion')
        # f1="""
        # ST_Intersects(
	    # (select geometry from munips where codmuni = {}), geometry
        # )
        # """
        # f1=f1.format(codigo)
        # f2="""
        # idvertido in (
        #     select id from asv_vertidos where
        # ST_Intersects(
	    # (select geometry from munips where codmuni = {}), geometry
        # ))
        # """
        # if vert:
        #     f2=f2.format(codigo)
        #     vert.setSubsetString(f1)
        #     aut.setSubsetString(f2)
        #     sanc.setSubsetString(f2)
    def filtro_pcv(self,codigo):
        conc=FILTRO_SPATIALITE_PUNTOS.format(codigo)
        fvert=FILTRO_PCV.format(3,conc)
        finsp=FILTRO_PCV.format(4,conc)
        falert=FILTRO_PCV.format(2,conc)
        vertido=lee_capa('pcv_vertidos')
        alerta=lee_capa('pcv_alertas')
        inspeccion=lee_capa('pcv_inspeccion')
        # expedientes=lee_capa_unsafe('pcv_expedientes')
        # descricions=lee_capa_unsafe('pcv_descricions')
        # str_flt="""
        # fktarefa in (
        #     select codigo from pcv where
        # ST_Intersects(
	    # (select geometry from munips where codmuni = {}), geometry
        # ))
        # """
        # f=str_flt.format(codigo)
        # expedientes.setSubsetString(f)
        # descricions.setSubsetString(f)
        vertido.setSubsetString(fvert)
        alerta.setSubsetString(falert)
        inspeccion.setSubsetString(finsp)

            
def filtra_seleccion(codigo=None):

    try:
        capas=ReferenciasCapas()
    except ExcepcionCapas as ex:
        QgsMessageLog.logMessage(ex, "Filtro", level=Qgis.Critical)
        iface.messageBar().pushMessage("Filtro", ex, level=Qgis.Critical)
        return
    if codigo:
        capas.municipio_capa.selectByExpression(f'"codmuni"={codigo}')
    else:
        munis=capas.municipio_capa.selectedFeatures()
        if len(munis)<1:
            QgsMessageLog.logMessage("Non se seleccionou ningun municipio para filtar", "Filtro", level=Qgis.Warning)
            iface.messageBar().pushMessage("Filtrado", "Non se seleccionou ningun municipio para filtar", level=Qgis.Warning)
            return
        codigo=capas.municipio_capa.selectedFeatures()[0]['codmuni']
    bbox_concello=capas.municipio_capa.boundingBoxOfSelected()
    project = QgsProject.instance()
    QgsExpressionContextUtils.setProjectVariable(project,'concello',codigo)
    capas.filtra_capas(codigo)
    iface.mapCanvas().setExtent(bbox_concello)
    iface.mapCanvas().refresh()
    iface.messageBar().pushMessage("Filtro", "OK", level=Qgis.Success)
    capas.municipio_capa.removeSelection()
    return codigo
    
if __name__ == "__main__":
    QgsMessageLog.logMessage("Inicio", "Filtro", level=Qgis.Success)
    filtra_seleccion()





