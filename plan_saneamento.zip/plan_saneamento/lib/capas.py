
from .util.wrapper_qgis import lee_capa


class Capa:
    def __init__(self) -> None: 
        self.capa=lee_capa(self.nome)
    def get_modo(self):
        """
        - postgres
        - spatialite

        """
        self.modo=self.capa.providerType()
        return self.modo

class Conexions(Capa):
    def __init__(self) -> None:
        self.nome='conexnucleoedar'
        super().__init__()
class Aglomeracion(Capa):
    def __init__(self) -> None:
        self.nome='aglomps'
        super().__init__()

class EDAR(Capa):
    def __init__(self) -> None:
        self.nome='edarps'
        super().__init__()

class Bombeo(Capa):
    def __init__(self) -> None:
        self.nome='bombps'
        super().__init__()

class TTorm(Capa):
    def __init__(self) -> None:
        self.nome='ttormps'
        super().__init__()

class Emisario(Capa):
    def __init__(self) -> None:
        self.nome='emisps'
        super().__init__()
class Colector(Capa):
    def __init__(self) -> None:
        self.nome='colps'
        super().__init__()
class PoligonoInd(Capa):
    def __init__(self) -> None:
        self.nome='polindps'
        super().__init__()
class FocoContaminacion(Capa):
    def __init__(self) -> None:
        self.nome='focaiscontps'
        super().__init__()
class Municipio(Capa):
    def __init__(self) -> None:
        self.nome='munips'
        super().__init__()
class Nucleo(Capa):
    def __init__(self) -> None:
        self.nome='nucleosps'
        super().__init__()
class Parroquia(Capa):
    def __init__(self) -> None:
        self.nome='parroquiasps'
        super().__init__()
class PuntosVertido(Capa):
    def __init__(self) -> None:
        self.nome='pvertps'
        super().__init__()
class Rios(Capa):
    def __init__(self) -> None:
        self.nome='riosps'
        super().__init__()
class FotosMuni(Capa):
    def __init__(self) -> None:
        self.nome='munipsfotos'
        super().__init__()
class FotosBomb(Capa):
    def __init__(self) -> None:
        self.nome='bombpsfotos'
        super().__init__()

class FotosTTorm(Capa):
    def __init__(self) -> None:
        self.nome='ttormpsfotos'
        super().__init__()
class FotosEDAR(Capa):
    def __init__(self) -> None:
        self.nome='edarpsfotos'
        super().__init__()

class ColectorEiel(Capa):
    def __init__(self) -> None:
        self.nome='eiel_colectores'
        super().__init__()