from qgis.utils import iface
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from .util.wrapper_qgis import lee_capa_emb 
from .util.utiles import LogQgis
from .capas import EDAR, Aglomeracion, Bombeo,Colector, TTorm
from qgis.gui import QgsMapToolIdentifyFeature
from .util.con_bd import ConnBD
import traceback

"""
Vincula os elementos seleccionados da capa bombeos a aglomeracions sobre a que se pincha
"""

def uid_aglom(xeom,ly):
    index_aglom=QgsSpatialIndex(ly)
    boundingBox=xeom.boundingBox()
    ent=index_aglom.intersects(boundingBox)
    request = QgsFeatureRequest()
    request.setFilterFids(ent)
    preseleccion=ly.getFeatures(request)
    uid = None 
    coincide=0
    for f in preseleccion:
        if f.geometry().contains(xeom):
            uid=f['uuid']
            coincide=coincide+1
    if uid and coincide == 1:
        return uid 
    elif uid and coincide >1:
        iface.messageBar().pushMessage("Aglomeracion", "Interseca con varias aglomeracions", level=Qgis.Warning)
    else:
        iface.messageBar().pushMessage("Aglomeracion", "Non intersecta con ningunha aglomeracion", level=Qgis.Warning)
    # res2=iface.openFeatureForm(capa_destino , feat, False)
def vincula_bombeos():
    pass 
# def vincula_bombeos():
#     x=[% @click_x %]
#     y=[% @click_y %]
#     xeom=QgsGeometry.fromPointXY(QgsPointXY(x,y))
#     ly=QgsProject.instance().mapLayer('[% @layer_id %]')
#     uidaglom=uid_aglom(xeom,ly)
#     if uidaglom:
#         layer = lee_capa_emb('bombps')
#         layer.startEditing()
#         for f in layer.selectedFeatures():
#             f['fkaglomuuid']=uidaglom
#             layer.updateFeature(f)
#         layer.commitChanges()
#         iface.messageBar().pushMessage("Bombeos", "Bombeos vinculados", level=Qgis.Success)
class VinculosAglomeracion:
    def __init__(self,aface) -> None:
        self.iface=aface
        self.layer=Aglomeracion().capa
        self.log=LogQgis("Vinculos aglomeracion")
        self.canvas=self.iface.mapCanvas()

    def set_colectores(self,feature):
        uid_aglom=feature['uuid']
        layer = Colector().capa
        layer.startEditing()
        for f in layer.selectedFeatures():
            f['fkaglomuuid']=uid_aglom
            layer.updateFeature(f)
        layer.commitChanges()
        self.iface.messageBar().pushMessage("Aglomeracion", "Collectores vinculados", level=Qgis.Success)
    def set_edar(self,feature):
        uid_aglom=feature['uuid']
        layer = EDAR().capa
        layer.startEditing()
        for f in layer.selectedFeatures():
            f['fkaglomuuid']=uid_aglom
            layer.updateFeature(f)
        layer.commitChanges()
        self.iface.messageBar().pushMessage("Aglomeracion", "EDAR vinculadas", level=Qgis.Success)
    def set_bombeos(self,feature):
        uid_aglom=feature['uuid']
        layer = Bombeo().capa
        layer.startEditing()
        for f in layer.selectedFeatures():
            f['fkaglomuuid']=uid_aglom
            layer.updateFeature(f)
        layer.commitChanges()
        self.iface.messageBar().pushMessage("Aglomeracion", "Bombeos vinculados", level=Qgis.Success)
    def set_tanques(self,feature):
        uid_aglom=feature['uuid']
        layer = TTorm().capa
        layer.startEditing()
        for f in layer.selectedFeatures():
            f['fkaglomuuid']=uid_aglom
            layer.updateFeature(f)
        layer.commitChanges()
        self.iface.messageBar().pushMessage("Aglomeracion", "Tanques vinculados", level=Qgis.Success)
    def vincula_colectores(self):

        self.vinc_col = QgsMapToolIdentifyFeature(self.canvas)
        self.vinc_col.setLayer(self.layer)
        self.vinc_col.featureIdentified.connect(self.set_colectores)
        self.canvas.setMapTool(self.vinc_col)
    def vincula_edar(self):

        self.vinc_edar = QgsMapToolIdentifyFeature(self.canvas)
        self.vinc_edar.setLayer(self.layer)
        self.vinc_edar.featureIdentified.connect(self.set_edar)
        self.canvas.setMapTool(self.vinc_edar)
    def vincula_bombeos(self):

        self.vinc_bomb = QgsMapToolIdentifyFeature(self.canvas)
        self.vinc_bomb.setLayer(self.layer)
        self.vinc_bomb.featureIdentified.connect(self.set_bombeos)
        self.canvas.setMapTool(self.vinc_bomb)
    def vincula_tanques(self):
        self.vinc_tanq = QgsMapToolIdentifyFeature(self.canvas)
        self.vinc_tanq.setLayer(self.layer)
        self.vinc_tanq.featureIdentified.connect(self.set_tanques)
        self.canvas.setMapTool(self.vinc_tanq)
    def buffer_colectores(self):
        self.bff_col = QgsMapToolIdentifyFeature(self.canvas)
        self.bff_col.setLayer(self.layer)
        self.bff_col.featureIdentified.connect(self.bf_cl)
        self.canvas.setMapTool(self.bff_col)
    def bf_cl(self,feature):
        uid_aglom=feature['uuid']
        x=f"call datos_psg.aglom_update_xeometria('{uid_aglom}')"
        self.log=LogQgis("Buffer Colectores")
        conn= ConnBD()
        try:
            cur_pg=conn.get_cursor()
            cur_pg.execute(x)
            conn.conn.commit()
            self.log.ok("Creado")
            cur_pg.close()
            self.iface.messageBar().pushMessage("Aglomeracion", "Buffer Xerado", level=Qgis.Success)
        except:
            self.log.ko("Non creado")
            self.log.ko(traceback.format_exc())
        finally:
                if cur_pg:
                    cur_pg.close()
                ConnBD.pecha_conexion()
        pass

def set_colectores(self,feature):
    log=LogQgis("Depuracion")
    log.info("Ok callback")
    uid_aglom=feature['uuid']
    layer = Colector().capa
    layer.startEditing()
    for f in layer.selectedFeatures():
        f['fkaglomuuid']=uid_aglom
        layer.updateFeature(f)
    layer.commitChanges()
    iface.messageBar().pushMessage("Colectores", "Collectores vinculados", level=Qgis.Success)

def vincula_colectores(self):
    log=LogQgis("Depuracion")
    log.info("Ok")
    vlayer=Aglomeracion().capa
    canvas = iface.mapCanvas()
    iface.setActiveLayer(vlayer)
    aglom_identify = QgsMapToolIdentifyFeature(canvas)

    # indicates the layer on which the selection will be done
    aglom_identify.setLayer(vlayer)
    # aglom_identify.setToolName('AglomIndent')
    # log.info(aglom_identify.toolName())

    # use the callback as a slot triggered when the user identifies a feature
    aglom_identify.featureIdentified.connect(set_colectores)
    # activation of the map tool
    canvas.setMapTool(aglom_identify)
    aglom_identify.activate()
    # iface.actionAglomIndent().trigger()



