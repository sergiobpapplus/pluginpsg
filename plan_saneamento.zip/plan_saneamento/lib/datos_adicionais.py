
from typing import List
from openpyxl import Workbook,load_workbook
from .util.utiles import Proxecto,LogQgis
from .util.con_bd import ConnBD
import re 
import os
from qgis.utils import iface
import urllib 
import json 
from qgis.core import Qgis,QgsMessageLog

class DireccionOsm:
    def __init__(self,lon,lat) -> None:
        self.lat=lat 
        self.lon=lon 
    def query_nominatim(self):
        url='https://nominatim.openstreetmap.org/reverse?lat={}&lon={}&zoom=1000&format=json'.format(self.lat,self.lon)
        req = urllib.request.Request(url)
        xx=urllib.request.urlopen(req)
        self.response= json.load(xx)  
    def _rural_urbano(self):
        if 'hamlet' in self.response['address'].keys() or 'farmyard' in self.response.keys():
            self.rural=True 
        else:
            self.rural=False
    def direccion(self):
        self.query_nominatim()
        QgsMessageLog.logMessage(f"{self.response['address']}", "Excel", Qgis.Info)
        self._rural_urbano()
        if self.rural:
            return self.get_direccion_rural()
        else:
            return self.get_direccion_urbana()
    def get_direccion_rural(self):
        valores=['road','farmyard','neighbourhood','hamlet','city_district']
        direccion=''
        i=0
        for v in valores:
            if v in self.response['address'].keys():
                if i==0:
                    direccion=direccion + f"{self.response['address'][v]}"
                    i=i+1
                else:
                    direccion=direccion + f" - {self.response['address'][v]}"
        return direccion 
    def get_direccion_urbana(self):
        valores=['leisure','road','neighbourhood','city_district']
        direccion=''
        i=0
        for v in valores:
            if v in self.response['address'].keys():
                if i==0:
                    direccion=direccion + f"{self.response['address'][v]}"
                    i=i+1
                else:
                    direccion=direccion + f" - {self.response['address'][v]}"
        return direccion 
def clear_parroquia(text):
    rgx='[\(\[].*?[\)\]]'
    texto=re.sub(rgx,'',text)
    return texto



class CodificaBase:
    def __init__(self,concello,log) -> None:
        self.concello=concello
        self.log:LogQgis=log
        self.parroquias_con_nulos:str=None
        self.element_parr:str=None
        self.element_parr_null:str=None
    def codifica(self):
        conn=ConnBD()
        try:
            cur_pg=conn.get_cursor()
            qr1=self.parroquias_con_nulos.format(self.concello)

            cur_pg.execute(qr1)
            parr_null=cur_pg.fetchall()
            cur_pg.close()
            parr_null=[i[0] for i in parr_null]
            if len(parr_null)>0:
                for parr in parr_null:
                    cur_pg=conn.get_cursor()
                    qr2=self.element_parr.format(parr)
                    self.log.info(qr2)
                    cur_pg.execute(qr2)
                    cods=cur_pg.fetchall()
                    cur_pg.close()
                    max_cod=0
                    self.log.info(f"{cods}")
                    for cod in cods:
                        if cod[1] is None or cod[1] =='':
                            pass 
                        else:
                            mm=re.match(self.mascara,cod[1])
                            if mm:
                                id_rel=mm.groups()[1]
                                try:
                                    id_int=int(id_rel)
                                    if id_int>max_cod:
                                        max_cod=id_int
                                except:
                                    pass
                    qr2=self.element_parr_null.format(parr)
                    self.log.info(qr2)
                    cur_pg=conn.get_cursor()
                    cur_pg.execute(qr2)
                    bbcod=cur_pg.fetchall()
                    for bb in bbcod:
                        max_cod=max_cod+1
                        nw_cod=self.mask_cod.format(parr,max_cod)
                        qr=self.qr_update.format(nw_cod,bb[0])
                        self.log.info(qr)
                        cur_pg=conn.get_cursor()
                        cur_pg.execute(qr)
                        if cur_pg.rowcount>0:
                            conn.conn.commit()
                            self.log.ok("Elemento codificado")
                        else:
                            conn.conn.rollback()
                        cur_pg.close()
        finally:
            if cur_pg:
                cur_pg.close()
            ConnBD.pecha_conexion()

class EDARCod(CodificaBase):
    def __init__(self,concello, log) -> None:
        super().__init__(concello,log) 
        self.mascara='^ED_(\d{7})_(\d{1,})$'
        self.mask_cod='ED_{}_{}'
        
        self.parroquias_con_nulos="""
        SELECT distinct(fkparroquia) from datos_psg.edarps where fkmunicod={} and (codedar is null or codedar='')and (int_borra is null or int_borra !=1)
        """
        self.element_parr="""
        SELECT uuid,codedar from datos_psg.edarps where fkparroquia = {}
        """
        self.element_parr_null="""
        SELECT uuid from datos_psg.edarps where (codedar is null or codedar='') and fkparroquia={} and (int_borra is null or int_borra !=1)
        """
        self.qr_update="""
        update datos_psg.edarps set codedar='{}' where uuid ='{}'
        """

class BombeosCod(CodificaBase):
    def __init__(self,concello,log) -> None:
        super().__init__(concello,log) 
        self.mascara='^BO_(\d{7})_(\d{1,})$'
        self.mask_cod='BO_{}_{}'
        
        self.parroquias_con_nulos="""
        SELECT distinct(fkparroquia) from datos_psg.bombps where fkmunicod={} and (codbomb is null or codbomb='') and (int_borra is null or int_borra !=1)
        """
        self.element_parr="""
        SELECT uuid,codbomb from datos_psg.bombps where fkparroquia = {}
        """
        self.element_parr_null="""
        SELECT uuid from datos_psg.bombps where (codbomb is null or codbomb = '') and fkparroquia={} and (int_borra is null or int_borra !=1)
        """
        self.qr_update="""
        update datos_psg.bombps set codbomb='{}' where uuid ='{}'
        """


class TTormCod(CodificaBase):
    def __init__(self,concello,log) -> None:
        super().__init__(concello,log) 
        self.mascara='^TT_(\d{7})_(\d{1,})$'
        self.mask_cod='TT_{}_{}'
        
        self.parroquias_con_nulos="""
        SELECT distinct(fkparroquia) from datos_psg.ttormps where fkmunicod={} and (codtt is null or codtt='') and (int_borra is null or int_borra !=1)
        """
        self.element_parr="""
        SELECT uuid,codtt from datos_psg.ttormps where fkparroquia = {}
        """
        self.element_parr_null="""
        SELECT uuid from datos_psg.ttormps where (codtt is null or codtt = '') and fkparroquia={} and (int_borra is null or int_borra !=1)
        """
        self.qr_update="""
        update datos_psg.ttormps set codtt='{}' where uuid ='{}'
        """



# class Emiscod(CodificaBase):
#     def __init__(self,concello,log) -> None:
#         super().__init__(concello,log) 
#         self.mascara='^TT_(\d{7})_(\d{1,})$'
#         self.mask_cod='TT_{}_{}'
        
#         self.parroquias_con_nulos="""
#         SELECT distinct(fkparroquia) from datos_psg.emisps where fkmunicod={} and (codemis is null or codemis = '')
#         """
#         self.element_parr="""
#         SELECT uuid,codemis from datos_psg.emisps where fkparroquia = {}
#         """
#         self.element_parr_null="""
#         SELECT uuid from datos_psg.emisps join datos_psg.edarps e on e.uuid=em.fkedaruuid where (codemis is null or codemis = '') and fkparroquia={}
#         """
#         self.qr_update="""
#         update datos_psg.emisps set codemis={} where uuid ='{}'
#         """




class Elemento:
    plantilla:Workbook=None
    def __init__(self,concello,log) -> None:
        self.concello=concello 
        self.log:LogQgis=log
    def query_ex(self):
        conn=ConnBD()
        try:
            cur_pg=conn.get_cursor()
            cur_pg.execute(self.cons_ex)
            self.ls_datos=cur_pg.fetchall()
        except:
            if cur_pg:
                cur_pg.close
            ConnBD.pecha_conexion()
    def escribe_folla(self):
        self.sheet=Elemento.plantilla[self.nome_folla]
        self.taboa_excel=self.sheet.tables[self.nome_taboa]
        conn=ConnBD()
        cur_pg=conn.get_cursor()
        try:
            cur_pg.execute(self.cons_ex)
            self.elementos_concello=cur_pg.fetchall()
            cur_pg.close()

        finally:
            if cur_pg:
                cur_pg.close()
            ConnBD.pecha_conexion()

    def elimina_folla(self):
        Elemento.plantilla.remove_sheet(self.sheet)



class ExcelEDAR(Elemento):
    def __init__(self,concello,log) -> None:
        super().__init__(concello, log)
        self.idxs={"COD":1,"PARROQUIA":2,"DIRECCION":3,"NOME":4}
        self.nome_folla='EDAR'
        self.nome_taboa='edarps'
        self.cons_ex=""" select ST_X(ST_Transform(ed.geom, 4326)), ST_Y(ST_Transform(ed.geom,4326 )),pa.nome,ed.codedar,ed.nombre
        from datos_psg.edarps ed join datos_psg.parroquiasps pa on pa.codigo=ed.fkparroquia where ed.fkmunicod={} and (int_borra is null or int_borra !=1) and fkaglomuuid is not null """
        self.cons_ex=self.cons_ex.format(self.concello)
    def escribe_folla(self):
        super().escribe_folla()
        if len(self.elementos_concello)>0:
            mx_row=6
            self.sheet.insert_rows(mx_row,len(self.elementos_concello)-1)
            fin=mx_row+len(self.elementos_concello)+1
            tbl=self.sheet.tables[self.nome_taboa]
            # tbl.ref=
            # mxx=40
            # if mxx>fin:
            #     self.sheet.delete_rows(fin,mxx-fin)
            # elif mxx<fin:
            #     self.sheet.insert_rows(mxx,fin-mxx)
            i=0
            for row in self.sheet.iter_rows(min_row=mx_row,min_col=2,max_row=mx_row+(len(self.elementos_concello)-1)):
                
                #codigo
                row[0].value=self.elementos_concello[i][3]
                #parroquia
                row[1].value=clear_parroquia(self.elementos_concello[i][2])
                #Direccion
                try:
                    row[2].value=DireccionOsm(self.elementos_concello[i][0],self.elementos_concello[i][1]).direccion()
                except: 
                    self.log.coidado(f"Non se puido obter a direccion : {self.nome_taboa} codigo: {self.elementos_concello[i][3]}") 
                #Nome
                row[3].value=self.elementos_concello[i][4]
                i=i+1
        else:
            self.elimina_folla()

        

class ExcelBombeo(Elemento):
    def __init__(self, concello, log) -> None:
        super().__init__(concello, log)
        self.nome_folla='BOMBEOS'
        self.nome_taboa='bombps'
        self.cons_ex=""" select ST_X(ST_Transform(bo.geom, 4326)), ST_Y(ST_Transform(bo.geom,4326 )),pa.nome,bo.codbomb,bo.nombre
        from datos_psg.bombps bo join datos_psg.parroquiasps pa on pa.codigo=bo.fkparroquia where bo.fkmunicod={}and (bo.int_borra !=1 or bo.int_borra is null) and fkaglomuuid is not null"""
        self.cons_ex=self.cons_ex.format(self.concello)
    def escribe_folla(self):
        super().escribe_folla()
        if len(self.elementos_concello)>0:
            mx_row=5
            fin=mx_row+len(self.elementos_concello)+1
            mxx=60
            if mxx>fin:
                self.sheet.delete_rows(fin,mxx-fin)
            elif mxx<fin:
                self.sheet.insert_rows(mxx,fin-mxx)
            i=0
            for row in self.sheet.iter_rows(min_row=mx_row,min_col=2,max_row=mx_row+(len(self.elementos_concello)-1)):
                
                #codigo
                row[0].value=self.elementos_concello[i][3]
                #parroquia
                row[1].value=clear_parroquia(self.elementos_concello[i][2])
                #Direccion
                try:
                    row[2].value=DireccionOsm(self.elementos_concello[i][0],self.elementos_concello[i][1]).direccion()
                except: 
                    self.log.coidado(f"Non se puido obter a direccion : {self.nome_taboa} codigo: {self.elementos_concello[i][3]}") 
                #Nome
                row[3].value=self.elementos_concello[i][4]
                i=i+1
        else:
            self.elimina_folla()

class ExcelTanques(Elemento):
    def __init__(self, concello, log) -> None:
        super().__init__(concello, log)
        self.nome_folla='TANQUES_TORMENTA'
        self.nome_taboa='ttormps'
        self.cons_ex=""" select ST_X(ST_Transform(tt.geom, 4326)), ST_Y(ST_Transform(tt.geom,4326 )),pa.nome,tt.codtt,tt.nombre
        from datos_psg.ttormps tt join datos_psg.parroquiasps pa on pa.codigo=tt.fkparroquia where tt.fkmunicod={} and (tt.int_borra !=1 or tt.int_borra is null)"""
        self.cons_ex=self.cons_ex.format(self.concello)
    def escribe_folla(self):
        super().escribe_folla()
        if len(self.elementos_concello)>0:
            mx_row=4
            fin=mx_row+len(self.elementos_concello)+1
            mxx=30
            if mxx>fin:
                self.sheet.delete_rows(fin,mxx-fin)
            elif mxx<fin:
                self.sheet.insert_rows(mxx,fin-mxx)
            i=0
            for row in self.sheet.iter_rows(min_row=mx_row,min_col=2,max_row=mx_row+(len(self.elementos_concello)-1)):
                
                #codigo
                row[0].value=self.elementos_concello[i][3]
                #parroquia
                row[1].value=clear_parroquia(self.elementos_concello[i][2])
                #Direccion
                try:
                    row[2].value=DireccionOsm(self.elementos_concello[i][0],self.elementos_concello[i][1]).direccion()
                except: 
                    self.log.coidado(f"Non se puido obter a direccion : {self.nome_taboa} codigo: {self.elementos_concello[i][3]}") 
                #Nome
                row[3].value=self.elementos_concello[i][4]
                i=i+1
        else:
            self.elimina_folla()


def codifica():
    log=LogQgis("Codificacion")
    codine=Proxecto().get_variable('concello')
    log.info(f"{codine}")
    edar=EDARCod(codine,log)
    bomb=BombeosCod(codine,log)
    ttorm=TTormCod(codine,log)
    # emis=Emiscod(codine,log)
    edar.codifica()
    bomb.codifica()
    ttorm.codifica()
    # emis.codifica()


def get_nom_concello(codine):
    qr_nome_concello=""" select nombre from datos_psg.munips where codmuni = {}""".format(codine)
    conn=ConnBD()
    try:
        cur_pg=conn.get_cursor()
        cur_pg.execute(qr_nome_concello)
        nom_cnc=cur_pg.fetchall()[0]
    finally:
        if cur_pg:
            cur_pg.close()

        ConnBD.pecha_conexion()
    return nom_cnc

def write_excel():
    ruta_prox=Proxecto().carpeta_proxecto()

    plantilla=os.path.join(ruta_prox,'plantilla_excel/plantilla_datos.xlsx')
    wbook=load_workbook(plantilla)
    Elemento.plantilla=wbook
    log=LogQgis("Plantilla de excel")
    codine=Proxecto().get_variable('concello')
    edar=ExcelEDAR(codine,log)
    edar.escribe_folla()
    bombeos=ExcelBombeo(codine,log)
    bombeos.escribe_folla()
    tt=ExcelTanques(codine,log)
    tt.escribe_folla()
    nome_conc=get_nom_concello(codine)
    nome_excel=f"{codine}_{nome_conc[0]}_datos adicionais.xlsx"
    wbook.save(os.path.join(ruta_prox,nome_excel))
    
def xera_excel():
    codifica()
    write_excel()
    iface.messageBar().pushMessage("Excel datos adicionais", "Excel xerado", level=Qgis.Success)

# import subprocess
# subprocess.check_call(['python', '-m', 'pip', 'install', 'xlwings'])