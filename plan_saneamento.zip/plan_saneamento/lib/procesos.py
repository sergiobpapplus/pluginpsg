from .capas import Municipio
from .util.utiles import Mensaxe
from qgis.core import QgsExpressionContext

def datos_adicionais():
    layer = Municipio().capa
    man=layer.actions()
    act=man.actions()
    f=next(layer.getFeatures())
    ctx=QgsExpressionContext()
    ex=True
    for a in act:
        if a.name()=='Excel Datos Adicionais':
            ex=False
            man.doAction(a.id(),f,ctx)
    if ex:
        Mensaxe().ko("Non se xerou o excel")

def desempaquetado():
    acccion='Desempaquetado'
    layer = Municipio().capa
    man=layer.actions()
    act=man.actions()
    f=next(layer.getFeatures())
    ctx=QgsExpressionContext()
    ex=True
    for a in act:
        if a.name()==acccion:
            ex=False
            man.doAction(a.id(),f,ctx)
    if ex:
        Mensaxe().ko("Non se desempaquetou")

def xerar_kml():
    acccion='Xerar KML'
    layer = Municipio().capa
    man=layer.actions()
    act=man.actions()
    f=next(layer.getFeatures())
    ctx=QgsExpressionContext()
    ex=True
    for a in act:
        if a.name()==acccion:
            ex=False
            man.doAction(a.id(),f,ctx)
    if ex:
        Mensaxe().ko("Non se xerou KML")