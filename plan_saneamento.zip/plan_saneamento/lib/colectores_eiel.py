import traceback
from typing import Dict

from .util.con_bd import ConnBD
from .util.utiles import LogQgis
from .capas import Colector, ColectorEiel,Capa










class QgistoSQL:
    def __init__(self) -> None:
        self.log=LogQgis("Copia EIEL")
        self.capa_qgis=None
        self.nome=None
        
        
    def get_insert(self):
        self.str_qr_ins="""
            insert into datos_psg.{} {} values {}
        """
         
    def get_dict(self) -> Dict:
        dc=self.__dict__.copy()
        return dc 
    def qgis_geom_to_sql(self,f)->str:
        tx=f.geometry().asWkt()
        geom_str=f"ST_GeomFromText('{tx}',25829)"
        return geom_str
    def get_dict_qgs(self,f):
        ls_values=[self.parse_valor_sql(i) for i in f.attributes() ]
        return dict(zip(f.fields().names(),ls_values))
    def limpia_campos(self,dcc):
        return dcc 
    def parse_valor_sql(self,valor):
        if type(valor) is float:
            valor=valor
        elif type(valor) is int:
            valor=valor
        elif type(valor) is bool:
            if valor:
                valor=1
            else:
                valor="null"
        elif type(valor) is str:
            valor=f"\'{valor}\'"
        elif valor is None or valor=='{}':
            return "null" 
        else:
            print(valor)
            return "null"
        return valor
class EielToSQl(QgistoSQL):
    def __init__(self) -> None:
        super().__init__()
        self.capa_qgis=ColectorEiel().capa
        self.nome=self.capa_qgis.name()
    def get_insert(self):
        super().get_insert()
        self.log.info("Get insert")
        ft=[f for f in self.capa_qgis.selectedFeatures()]
        ls=[]
        if len(ft)<1:
            self.log.info("Non hai nada seleccionado")
            return 
        for f in ft:
            dcc=self.get_dict_qgs(f)

            dcc=self.limpia_campos(dcc)

            dcc['geom']=self.qgis_geom_to_sql(f)

            campos=dcc.keys()
            
            i=0
            qr_c='('
            qr_v='('
            for c in campos:
                if i==0:
                    qr_c=qr_c+c
                else:
                    qr_c=qr_c+','+c
                i+=1
            qr_c=qr_c+')'
            campos=qr_c
            valores=dcc.values()
            i=0
            for v in valores:
                if i == 0:
                    qr_v=qr_v+ f"{v}"
                else:
                    qr_v=qr_v+','+f"{v}"
                i+=1
            valores=qr_v+')'
            str_qr_ins=f"insert into datos_psg.colps {campos} values {valores} ON CONFLICT (uuid) DO NOTHING;"
            self.log.info(f"{str_qr_ins}")
            ls.append(str_qr_ins)
        return ls 
            


    def limpia_campos(self, dcc):
        dcc=super().limpia_campos(dcc)
        del dcc['ogc_fid']
        del dcc['orx']
        del dcc['refe']
        return dcc 
        
def copia_colectores_eiel():
    log=LogQgis("Copia EIEL")
    log.info("copia fn")
    colectores= Colector()
    # if colectores.get_modo() != 'postgres':
    #     log.ko("No postgres")
    #     log.ko(f"{colectores.get_modo()}")
    #     return 
    colectoresEiel=ColectorEiel().capa
    ordes=EielToSQl()
    ordes=ordes.get_insert()
    log.info(f"{ordes}")
    conn=ConnBD()
    try:
        copia=CopiaSqlEiel().insert(ordes,conn)
        ConnBD.conn.commit()
    except:
        log.ko("Non copiado")
        log.ko(traceback.format_exc())
    finally:
        ConnBD.pecha_conexion()       


class CopiaSqlEiel:
    def __init__(self) -> None:
        self.log= LogQgis("Copia EIEL")
    def insert(self,ls,conn):

        try:
            for x in ls:
                cur_pg=conn.get_cursor()
                cur_pg.execute(x)

                self.log.ok("Copiado")
                cur_pg.close()
        except:
            self.log.ko("Non copiado")
            self.log.ko(traceback.format_exc())
        finally:

                if cur_pg:
                    cur_pg.close()



