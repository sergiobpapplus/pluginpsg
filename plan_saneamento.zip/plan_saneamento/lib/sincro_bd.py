import pathlib
from typing import List
from qgis.core import *
from .util.con_bd import *
from .util.utiles import DialogoArchivo,LogQgis,Rutas,Proxecto
from PyQt5.QtWidgets import QMessageBox
from qgis.utils import iface
from .fotos_servidor import completado,qgis_task
import uuid
import re

CAPAS_BD=[
    "aglomps",
    "edarps",
    "nucleosedar",
    "nucleosedar2",
    "conexnucleoedar",
    "conexiones",
    "conexiones2",
    "bombps",
    "ttormps",
    "colps",
    "emisps",
    "pvertps",
    "munips",
    "polindps",
    "focaiscontps",
    "nucleosps",
    "munipsfotos",
    "munipsfoto",
    "bombpsfotos",
    "bombpsfoto",
    "ttormpsfoto",
    "ttormpsfotos",
    "edarpsfoto",
    "edarpsfotos"
]
DESF_FOTOS={
    'edarpsfoto':"edarpsfotos",
    "edarpsfotos":"edarpsfotos",
    "bombpsfoto":"bombpsfoto",
    "bombpsfotos":"bombpsfoto",
    "ttormpsfoto":"ttormpsfoto",
    "ttormpsfotos":"ttormpsfoto",
    "munipsfoto":"munipsfotos",
    "munipsfotos":"munipsfotos",
    "conexiones":"conexnucleoedar",
    "conexiones2":"conexnucleoedar",
    "nucleosedar2":"conexnucleoedar",
    "nucleosedar":"conexnucleoedar"
}
DESF_EDAR_FOTOS={
    "fkedaruuid":"uuidedar",
    "fkuuidedar":"uuidedar"
}
class QgLog(LogQgis):
    def __init__(self, pestana):
        super().__init__(pestana)

def parse_valor_sql(valor):
    if type(valor) is float:
        valor=valor
    elif type(valor) is int:
        valor=valor
    elif type(valor) is bool:
        if valor:
            valor=1
        else:
            valor="null"
    elif type(valor) is str:
        valor=f"\'{valor}\'"
    else:
        raise Exception
    return valor

#             municipios_bd.updateFeature(f)
class OGRUtiles:
    def campos_ogr_lyr(lyr):
        ldfn = lyr.GetLayerDefn()
        campos=[]
        for c in range(ldfn.GetFieldCount()):
            fdefn = ldfn.GetFieldDefn(c)
            campos.append(fdefn.name)
        # print(campos)
        return campos
    def valores_feature_ogr(feat):
        valores=[]
        for c in range(feat.GetFieldCount()):
            valores.append(feat.GetField(c))
        return valores 

    def dcc_feature_ogr(lyr,feat):
        campos=OGRUtiles.campos_ogr_lyr(lyr)
        valores=OGRUtiles.valores_feature_ogr(feat)
        dcc=dict(zip(campos,valores))
        return dcc 



class CambiosFeature:
    def __init__(self,capa,uid,cambios) -> None:
        self.capa=capa
        self.uuid=uid 
        self.cambios=cambios
class CambiosCapa:
    ruta_pkg_or=None 
    ruta_pkg_mod=None
    def __init__(self,nome_taboa,nome_enpaquete,log,muni,munixeom) -> None:
        self.log:QgLog=log
        self.nome_taboa=nome_taboa 
        self.nome_enpaquete=nome_enpaquete
        self.cambios={}
        self.xeom_mod={}
        self.layer_or=None 
        self.layer_mod=None
        self.engadidos=[]
        self.eliminados=[]
        self.conservados=[]
        self.municipio=muni 
        self.munixeom=munixeom
        self.abre_capa_gpkg()
    def crea_novos(self):
        if len(self.engadidos)>0:#and self.nome_taboa not in ["conexiones","conexiones2","nucleosedar2,nucleosedar"]:
            self.log.info("Novo")
            str_insert="""
            insert into datos_psg.{} ({}) values ({})
            """
            conn_mod=OgrGpkg(self.ruta_pkg_mod)
            conn_mod.abre_ds_lectura()
            lyr=conn_mod.ds.GetLayer(self.nome_enpaquete)
            conn_pg=ConnBD()
            cur_pg=None
            try:
                for x in self.engadidos:
                    if x is not None:
                        feat=self.get_ogr_feature_by_uuid(x,lyr)
                        xeome=feat.GetGeometryRef()
                        if xeome is None or self.munixeom.Intersects(xeome):
                            dcc=OGRUtiles.dcc_feature_ogr(lyr,feat)
                            dcc_nonull={}
                            for k,v in dcc.items():
                                if self.nome_taboa in ["edarpsfoto","edarpsfotos"] and k in ["fkedaruuid","fkuuidedar"]:
                                    campo='uuidedar' 
                                else:
                                    campo=k
                                if v is None or k =='id' or k == 'codcol' or k == 'codedar' or k == 'codbomb' or k == 'codtt' or k == 'codvert':
                                    pass 
                                else:
                                    dcc_nonull[campo]=parse_valor_sql(v)

                            xeom=feat.GetGeometryRef()
                            if xeom and self.nome_taboa not in ["conexnucleoedar","conexiones","conexiones2","nucleoedar2","nucleosedar"]:
                                dcc_nonull['geom']=f"ST_GeomFromText('{xeom.ExportToWkt()}',25829)"
                            if self.nome_taboa in DESF_FOTOS.keys():
                                nm_tbl=DESF_FOTOS[self.nome_taboa]
                            else:
                                nm_tbl=self.nome_taboa
                            
                            str_field=''
                            str_value=''
                            i=0
                            for k,v in dcc_nonull.items():
                                if i==0:
                                    str_field=str_field+f"{k}"
                                    str_value=str_value+f"{v}"
                                else:
                                    str_field=str_field+','+f"{k}"
                                    str_value=str_value+','+f"{v}"
                                i=i+1
                            qr=str_insert.format(nm_tbl,str_field,str_value)
                            # self.log.info(qr)
                            cur_pg=conn_pg.get_cursor()
                            try:
                                cur_pg.execute(qr)
                                if cur_pg.rowcount > 0 :
                                    conn_pg.conn.commit()
                                    self.log.ok(f"Feature engadido capa:{self.nome_taboa} --- uuid:{x}")
                            except ps.errors.UniqueViolation as e:
                                self.log.coidado(f"Xa existe feature capa:{self.nome_taboa} --- uuid:{x}")
                                self.log.coidado(f"{e}")
                                conn_pg.conn.rollback()
                            cur_pg.close()
                            cur_pg=None
                        else:
                            self.log.coidado(f"Feature non creado (fora do municipio) capa:{self.nome_taboa} -- uuid{x}") 
            finally:
                if cur_pg:
                    cur_pg.close()
                if ConnBD.conn:
                    ConnBD.pecha_conexion()
                if conn_mod:
                    conn_mod.pecha_ds() 
        # elif self.nome_taboa in ["conexiones","conexiones2","nucleosedar2,nucleosedar"]:
        #     self.log.coidado("Pendente de actualizar as conexiones")
    def borra(self):
        if len(self.eliminados)>0:# and self.nome_taboa not in ["conexiones","conexiones2","nucleosedar2","nucleosedar"]:
            str_borra="""
            update datos_psg.{} set int_borra=1 where {} = {}
            """
            conn_pg=ConnBD()
            cur_pg=None
            con_ogr_pk=OgrGpkg(self.ruta_pkg_or)
            con_ogr_pk.abre_ds_lectura()
            ly=con_ogr_pk.ds.GetLayer(self.nome_enpaquete)
            try:
                for f in self.eliminados:
                    feat=self.get_ogr_feature_by_uuid(f,ly)
                    xeome=feat.GetGeometryRef()
                    if xeome is None or self.munixeom.Intersects(xeome):
                        if self.nome_taboa in DESF_FOTOS.keys():
                            nm_tbl=DESF_FOTOS[self.nome_taboa]
                        else:
                            nm_tbl=self.nome_taboa
                        qr=str_borra.format(nm_tbl, 'uuid',f"\'{f}\'")
                        # self.log.info(f"{qr}")
                        cur_pg=conn_pg.get_cursor()
                        cur_pg.execute(qr)
                        if cur_pg.rowcount>0:
                            ConnBD.conn.commit()
                            self.log.ok(f"Feature borrado capa:{self.nome_taboa}---uuid:{f}")
                        cur_pg.close()
                        cur_pg=None 
                    else:
                        self.log.coidado(f"Feature non eliminado (fora do municipio) capa {self.nome_taboa} --- uuid {f}")
            except:
                self.log.ko(f"Capa {self.nome_taboa} ---- uuuid {f}")
                raise
            finally:
                if ConnBD.conn:
                    ConnBD.pecha_conexion()
                if cur_pg:
                    cur_pg.close()
                del ly 
                con_ogr_pk.pecha_ds()
        # elif self.nome_taboa in ["conexiones","conexiones2","nucleosedar2,nucleosedar"]:
        #     self.log.coidado("Pendente de actualizar as conexiones")
    def actualiza_att(self):
        if len(self.cambios)>0:
            str_update="""
            update datos_psg.{} set {} where {} = {}
            """
            conn_pg=ConnBD()
            cur_pg=None
            try:
                for k,v in self.cambios.items():
                    str_set=''
                    i=0
                    for a in v:
                        if a[0]=='id' or  a[0] == 'codcol' or a[0] == 'codedar' or a[0] == 'codbomb' or a[0] == 'codtt' or a[0] == 'codvert':
                            pass 
                        else:
                            if i!=0:
                                str_set=str_set+','
                            if self.nome_taboa in ["edarpsfoto","edarpsfotos"] and a[0] in ["fkedaruuid","fkuuidedar"]:
                                str1="uuidedar" 
                            else:
                                str1=a[0]
                            if a[1] is None:
                                str2='null'
                            else:
                                str2=parse_valor_sql(a[1])

                            str_set=str_set+f"{str1}={str2}"
                            i=i+1
                    if self.nome_taboa =='munips':
                        qr=str_update.format(self.nome_taboa,str_set,'codmuni',k)

                    else:
                        if self.nome_taboa in DESF_FOTOS.keys():
                            nm_tbl=DESF_FOTOS[self.nome_taboa]
                        else:
                            nm_tbl=self.nome_taboa
                        qr=str_update.format(nm_tbl,str_set,'uuid',f"\'{k}\'")
                    # self.log.info(f"{qr}")
                    cur_pg=conn_pg.get_cursor()
                    cur_pg.execute(qr)
                    if cur_pg.rowcount>0:
                        ConnBD.conn.commit()
                        self.log.ok(f"Atributos actualizados capa:{self.nome_taboa}---uuid:{k}")
                    cur_pg.close()
                    cur_pg=None 
            except:
                self.log.ko(f"Erro actualizando atributos capa:{self.nome_taboa} --- uuid {k}")
                raise
            finally:
                if ConnBD.conn:
                    ConnBD.pecha_conexion()
                if cur_pg:
                    cur_pg.close()

    def actualiza_xeom(self):
        if len(self.xeom_mod)>0:
            str_update_xeom="""
            update datos_psg.{} set geom = ST_GeomFromText('{}',25829) where uuid = '{}'
            """
            conn_pg=ConnBD()
            cur_pg=None 
            try:
                for k,v in self.xeom_mod.items():
                    qr=str_update_xeom.format(self.nome_taboa,v,k)
                    # self.log.info(f"{qr}")
                    cur_pg=conn_pg.get_cursor()
                    cur_pg.execute(qr)
                    if cur_pg.rowcount>0:
                        ConnBD.conn.commit()
                        self.log.ok(f"Xeometria actualizada capa : {self.nome_taboa}---- uuid : {k}")
                    cur_pg.close()
                    cur_pg=None 
            except:
                self.log.ko(f"Erro actualizando xeometria capa: {self.nome_taboa} --- uuid : {k} ")
                raise
            finally:
                if ConnBD.conn:
                    ConnBD.pecha_conexion()
                if cur_pg:
                    cur_pg.close()

    def get_diferencias(self):
        if len(self.conservados)<1:
            self.log.info(f"{self.nome_taboa}Non se conservou ningun feature ")
            return
        else:
            # for f in self.get_features_by_list_uuid(self.conservados,self.layer_mod):
            ds_or=OgrGpkg(self.ruta_pkg_or)
            ds_or.abre_ds_lectura()
            ds_mod=OgrGpkg(self.ruta_pkg_mod)
            ds_mod.abre_ds_lectura()
            ly_md=ds_mod.ds.GetLayer(self.nome_enpaquete)
            ly_or=ds_or.ds.GetLayer(self.nome_enpaquete)
            try:
                for f in self.conservados:
                    # orix=self.get_feature_by_uuid(f,self.layer_or)
                    # mod=self.get_feature_by_uuid(f,self.layer_mod)
                    # mod_att=mod.attributes()
                    # mod_fld=mod.fields().names()
                    # dcc_mod=dict(zip(mod_fld,mod_att))
                    # dcc_or=dict(zip(orix.fields().names(),orix.attributes()))
                    if self.nome_taboa == 'munips':
                        orix=self.get_ogr_feature_by_uuid(f,ly_or,'codmuni')
                        mod=self.get_ogr_feature_by_uuid(f,ly_md,'codmuni')
                    else:
                        orix=self.get_ogr_feature_by_uuid(f,ly_or)
                        mod=self.get_ogr_feature_by_uuid(f,ly_md)  

                    dcc_or=OGRUtiles.dcc_feature_ogr(ly_or,orix)
                    dcc_mod=OGRUtiles.dcc_feature_ogr(ly_md,mod)

                    # del dcc_or['fid']
                    # del dcc_mod['fid']

                    or_set=set(dcc_or.items())
                    mod_set=set(dcc_mod.items())

                    difere=(mod_set-or_set)
                    if len(difere)>0:
                        if self.nome_taboa == 'munips':
                            self.cambios[mod['codmuni']]=difere
                        else:
                            self.cambios[mod['uuid']]=difere
                        self.log.info(f"{self.nome_taboa} --- {f} ----- campos con cambios : {len(difere)}")
                        # self.log.info(f"{difere}")
                    
                    g_or=orix.GetGeometryRef()
                    g_md=mod.GetGeometryRef()
                    if g_md and self.nome_taboa not in ["conexnucleoedar","conexiones","conexiones2","nucleoedar2"]:
                        if not g_md.Equals(g_or):
                            self.xeom_mod[f]=g_md.ExportToWkt()
                            self.log.info(f"Xeometria modificada {self.nome_taboa} ---- {f}")
                    # else:
                    #     self.log.coidado(f"Non e se atoparon modificacions na capa {self.nome_taboa}")
            except:
                self.log.ko(f"Capa: {self.nome_taboa} ---- uuid: {f}")
                raise
            finally:
                del ly_md
                del ly_or
                ds_or.pecha_ds()
                ds_mod.pecha_ds()
                #print(len(mod_set-or_set))
    def get_feature_by_uuid(self,uid,capa):
        str_nd='"uuid" like \'{}\''.format(uid)
        feature=None
        # expr=QgsExpression(str_nd)
        # req=QgsFeatureRequest().setFilterExpression(str_nd)
        # try:
        #     feat = next(capa.getFeatures(req))
        # except:
        #     self.log.ko(f"Capa:{self.nome_taboa} ---- uuid: {uid} --- capa_paquete: {capa.name()}")
        #     self.log.ko(f"{str_nd}")
        #     raise
        # return feat
        # capa.setSubsetString(str_nd)
        # for f in capa.getFeatures():
        #     feature=f 
        # capa.setSubsetString('')
        # return feature

    def get_ogr_feature_by_uuid(self,uid,layer,ident='uuid'):
        if ident=='uuid':
            uid=f"\'{uid}\'"
        str_nd='{} = {}'.format(ident,uid)
        layer.SetAttributeFilter(str_nd)
        feature=None
        for f in layer:
            feature=f
        layer.ResetReading()
        if feature is None:
            raise Exception
        return feature
    def get_features_by_list_uuid(self,uids,capa):
        if len(uids)>1:
            str_nd='"uuid" in array({})'.format(self._format_cons_uids(uids))
        else:
            str_nd='"uuid" = \'{}\''.format(uids)
        self.log.info(str_nd)
        expr=QgsExpression(str_nd)
        req=QgsFeatureRequest(expr)
        return capa.getFeatures(req)
    def _format_cons_uids(self,ls_uids):
        cadea=''
        i=0
        for l in ls_uids:
            if i == 0:
                cadea=cadea+"\'"+l+"\'"
            else:
                cadea=cadea+",\'"+l+"\'"
            i=i+1
        return cadea
    def _quit_uid(self,nome:str)->str:
        aux=nome.split('_')
        if len(aux)>5:
            d=aux[:-5]
            i=0
            nf=""
            for x in d:
                if i ==0:
                    nf=nf+x
                else:
                    nf=nf+'_'+x
                i=i+1
        else:
            nf=nome
        return nf
    def abre_capa_gpkg(self):
        if self.layer_or is None:
            punteiro_capa_or=CambiosCapa.ruta_pkg_or 
            self.layer_or = QgsVectorLayer(punteiro_capa_or, self.nome_enpaquete, "ogr")
            try:
                if not self.layer_or.isValid():
                    raise Exception
            except:
                self.log.ko(f"Erro!!! Capa {self.nome_enpaquete} non atopada en {CambiosCapa.ruta_pkg_or}")
                raise
        if self.layer_mod is None:
            punteiro_capa_mod=CambiosCapa.ruta_pkg_mod 
            self.layer_mod = QgsVectorLayer(punteiro_capa_mod, self.nome_enpaquete, "ogr")
            try:
                if not self.layer_mod.isValid():
                    raise Exception
            except:
                self.log.ko(f"Erro!!! Capa {self.nome_enpaquete} non atopada en {CambiosCapa.ruta_pkg_mod}")
                raise 
class UnPack:
    def __init__(self,pkg_orixe,pkg_mod):
        CambiosCapa.ruta_pkg_or=pkg_orixe
        CambiosCapa.ruta_pkg_mod=pkg_mod
        self.pkg_orixe=pkg_orixe
        self.pkg_mod=pkg_mod
        self.log=QgLog("Desempaquetado")
        self.log.savelog(os.path.join(Rutas.carpeta(pkg_mod),'desempaquetado.log'))
        # [taboa_qfield,nome_tbl_corto,nome_qgis,layer.id,fid]
        self.features_engadidos=[]
        self.lista_capas:List[CambiosCapa]=[]
        # self.lista_capas_eng:List[CambiosCapa]=[]
        # self.lista_capas_borr:List[CambiosCapa]=[]

        # [taboa_qfield,nome_campo,tipo_campo,nome_tbl_corto,nome_qgis,layer.id,commit,fid,campo_id,valor]
        self.actualizacions=[]
        # [taboa_qfield, nome_tbl_corto, nome_qgis,layer.id, fid
        self.borrados=[]
        self.num_borrados=0
        self.num_engadidos=0
        self.num_actualizados=0
        self.municipio=None 
    def dif_dcc(self,orixe,modificado):
        """
        :param orixe: diccionario con nome atributo valor de orixe
        :param orixe: diccionario con nome atributo valor modificado
        :return: list do set coas diferencias
        """
        orixe_set=set(orixe)
        mod_set=set(modificado)
        dif= mod_set-orixe_set
        return dif
    def parse_nomes(self,rs):
        """
        :param rs:  resulset das consultas
        :return: o rs co nome de capa modificado extraendo o uuid xerado por qgis (incluese no pirmeiro elemento)
        """
        ls=[]
        for r in rs:
            sb_ls=[]
            df=self._quit_uid(r[0])
            sb_ls.append(df)
            sb_ls.extend(list(r))
            ls.append(sb_ls)
        return ls
    def _quit_uid(self,nome:str)->str:
        aux=nome.split('_')
        if len(aux)>5:
            d=aux[:-5]
            i=0
            nf=""
            for x in d:
                if i ==0:
                    nf=nf+x
                else:
                    nf=nf+'_'+x
                i=i+1
        else:
            nf=nome
        return nf
    def get_municipio(self):
        self.log.subseccion("OBTENCIÓN DO MUNICIPIO")
        q_nucl_pqk="""
        select fkmunicod  from {} group by fkmunicod ORDER by count(uuid) LIMIT 1;
        """
        nome_de_taboa="""
        SELECT table_name  from gpkg_contents WHERE table_name like '{}_%'
        """
        ogr_md=OgrGpkg(self.pkg_mod)
        ogr_md.abre_ds_lectura()
        
        conn_md=ConnSqlite(self.pkg_mod)
        taboa_nucleos=conn_md.get_cursor().execute(nome_de_taboa.format('nucleosps')).fetchone()[0]
        #
        ###
        #####

        codine=conn_md.get_cursor().execute(q_nucl_pqk.format(taboa_nucleos)).fetchone()[0]
        # codine=15004
        self.log.info(f"{codine}")
        taboa_municipios=conn_md.get_cursor().execute(nome_de_taboa.format('munips')).fetchall()
        # self.log.info(f"{taboa_municipios}")
        for t in taboa_municipios:
            if re.match('^munips_\w{8}_\w{4}_\w{4}_\w{4}_\w{12}$',t[0]):
                # self.log.info(f"{t[0]}")
                taboa_muni=t[0]
        ly=ogr_md.ds.GetLayer(taboa_muni)
        ly.SetAttributeFilter(f"codmuni = {codine}")
        for f in ly:
            self.munixeom=f.GetGeometryRef().Buffer(2000.0)
        if self.munixeom is None or codine is None:
            self.log.ko("Non se puido obter o contorno do municipio")
            raise Exception("Non se puido obter o municipio")
        self.municipio=codine
        conn_md.pecha()
        del ly 
        ogr_md.pecha_ds()
        return self.municipio
    def cons_espacial(self,xeometria,capa):
        """
        :param xeometria:  xeometria de filtro 
        :param capa:  capa a filtrar 
        :return: lista de features
        """
        boundingBox=xeometria.boundingBox()

        index=QgsSpatialIndex(capa)
        ent=index.intersects(boundingBox)
        request = QgsFeatureRequest()
        request.setFilterFids(ent)
        preseleccion=capa.getFeatures(request)
        ls=[]
        for fet in preseleccion:
            if fet.geometry().intersects(xeometria):
                ls.append(fet)
        return ls 
    def obter_taboas(self):
        conn=ConnSqlite(self.pkg_mod)
        str_cons="""
        select table_name from gpkg_contents 
        """
        ls_taboas=conn.get_cursor().execute(str_cons).fetchall()
        ls_taboas=[i[0] for i in ls_taboas]
        ls_def={}
        for l in ls_taboas:
            lplano=self._quit_uid(l)
            if lplano in CAPAS_BD:
                capa=CambiosCapa(lplano,l,self.log,self.municipio,self.munixeom)
                ls_def[lplano]=capa
        ls_ord=[]
        for c in CAPAS_BD:
            try:
                ls_ord.append(ls_def[c])
            except:
                pass

        self.lista_capas=ls_ord
        conn.pecha() 
    def _format_cons_uids(self,ls_uids):
        cadea=''
        i=0
        for l in ls_uids:
            if i == 0:
                cadea=cadea+"\'"+l+"\'"
            else:
                cadea=cadea+",\'"+l+"\'"
            i=i+1
        # self.log.info(f"{cadea}")
        return cadea
    def corrixe_uids(self):
        conn = OgrGpkg(self.pkg_mod)
        conn.abre_ds_escritura()
        for c in self.lista_capas:
            if c.nome_taboa !='munips':
                ly=conn.ds.GetLayer(c.nome_enpaquete)
                ly.SetAttributeFilter('uuid is null')
                for f in ly:
                    f.SetField("uuid",f"{uuid.uuid1()}")
                    ly.SetFeature(f) 
                del ly 
        conn.pecha_ds()
                
                # str_uidnull="""select fid from {} where uuid is null or uuid = '' """
                # str_corr="""update {} set uuid = {} where fid = {}"""
                # qr0=str_uidnull.format(c.nome_enpaquete)
                # self.log.info(f"{qr0}")
                # fids=conn.ds.ExecuteSQL(qr0)
                # self.log.info("ExecuteSql")
                # self.log.info(f"{fids}")
                # fids=[i for i in fids]
                # # self.log.info(f"{fids}")
                # if len(fids)>0:
                #     self.log.coidado("Features sen uuids")
                #     for x in fids:
                #         self.log.info("Correxindo uuids")
                #         qr1=str_corr.format(c.nome_enpaquete,f"\'{uuid.uuid1()}\'",x)
                #         self.log.info(f"{qr1}")
                #         # lyt=conn.ds.GetLayer(c.nome_enpaquete)
                #         self.log.info(qr1)
                #         conn.ds.StartTransaction()
                #         res=conn.ds.ExecuteSQL(qr1)
                #         self.log.info(f"{res}")
                #         conn.ds.CommitTransaction()
                #         # del lyt
                # conn.pecha_ds()
    def engadidos_totais(self):
        
        self.log.subseccion("Historial de features engadidos")  
        self.corrixe_uids()      
        conn_or=ConnSqlite(self.pkg_orixe)
        str_or=""" select uuid from {}"""
        str_mod="""select uuid from {} where uuid {} {}"""
        conn_md=ConnSqlite(self.pkg_mod)
        for c in self.lista_capas:
            if c.nome_taboa != 'munips':

                        # conn_md.get_cursor().execute(qr1)
                        # conn_md.conn.commit()


                uids_or=conn_or.get_cursor().execute(str_or.format(c.nome_enpaquete)).fetchall()
                uids_or=[i[0] for i in uids_or]
                # self.log.info(f"{uids_or}")
                if len(uids_or)>0:
                    # self.log.info(f"Capa {c.nome_taboa} ---- Numero de features en orixen: {len(uids_or)}")
                    if len(uids_or)==1:
                        qr=str_mod.format(c.nome_enpaquete,'not like',self._format_cons_uids(uids_or))
                        # self.log.info(qr)
                        uids_mod=conn_md.get_cursor().execute(qr).fetchall()
                    else:
                        qr=str_mod.format(c.nome_enpaquete,'not in',f"({self._format_cons_uids(uids_or)})")
                        # self.log.info(qr)
                        uids_mod=conn_md.get_cursor().execute(qr).fetchall()
                    if len(uids_mod)>0:
                        uids_mod=[i[0] for i in uids_mod]
                        self.log.ok(f"Capa {c.nome_taboa} ---- Numero de features engadidos: {len(uids_mod)}")
                        c.engadidos=uids_mod 
                else:
                    qr=str_or.format(c.nome_enpaquete)
                    uids_mod=conn_md.get_cursor().execute(qr).fetchall()
                    if len(uids_mod)>0:
                        uids_mod=[i[0] for i in uids_mod]
                        self.log.info(f"Capa {c.nome_taboa} ---- Numero de features engadidos: {len(uids_mod)}")
                        c.engadidos=uids_mod 

        total=0
        for c in self.lista_capas:
            total=total+len(c.engadidos)
        self.engadidos_totais=total
        self.log.ok(f"Features engadidos : {self.engadidos_totais}")
        conn_md.pecha()
        conn_or.pecha() 


    def borrados_totais(self):
        self.log.subseccion("Historial de borrados")

        conn_or=ConnSqlite(self.pkg_orixe)
        str_mod=""" select uuid from {}"""
        str_or="""select uuid from {} where uuid {} {}"""
        conn_md=ConnSqlite(self.pkg_mod)
        for c in self.lista_capas:
            if c.nome_taboa != 'munips':
                uids_mod=conn_md.get_cursor().execute(str_mod.format(c.nome_enpaquete)).fetchall()
                uids_mod=[i[0] for i in uids_mod]
                if len(uids_mod)>0:
                    # self.log.info(f"Capa {c.nome_taboa} ---- Numero de features en modificado: {len(uids_mod)}")
                    if len(uids_mod)==1:
                        uids_or=conn_or.get_cursor().execute(str_or.format(c.nome_enpaquete,'not like',self._format_cons_uids(uids_mod))).fetchall()
                    else:
                        try:
                            qr=str_or.format(c.nome_enpaquete,'not in',f"({self._format_cons_uids(uids_mod)})")
                        except:
                            self.log.ko(f"Erro capa {c.nome_taboa}")
                            raise
                        uids_or=conn_or.get_cursor().execute(qr).fetchall()
                    if len(uids_or)>0:
                        uids_or=[i[0] for i in uids_or]
                        self.log.info(f"Capa {c.nome_taboa} ---- Numero de features borrados: {len(uids_or)}")
                        c.eliminados=uids_or 
                else:
                    qr=str_mod.format(c.nome_enpaquete)
                    uids_or=conn_or.get_cursor().execute(qr).fetchall()
                    if len(uids_or)>0:
                        uids_or=[i[0] for i in uids_or]
                        c.eliminados=uids_or
                        self.log.ok(f"Capa {c.nome_taboa} ---- Numero de features borrados: {len(uids_or)}")

        total=0
        for c in self.lista_capas:
            total=total + len(c.eliminados)
        self.num_borrados=total 
        conn_md.pecha()
        conn_or.pecha() 
        self.log.ok("TOTAL DE FEATURES BORRADO : {} ".format(self.num_borrados))
        return True
    def actualizados_totais(self):
        self.log.subseccion("Historial de actualizados")

        conn_or=ConnSqlite(self.pkg_orixe)
        str_mod=""" select uuid from {} where uuid is not null"""
        str_or="""select uuid from {} where uuid {} {}"""
        conn_md=ConnSqlite(self.pkg_mod)
        total=0
        for c in self.lista_capas:
            if c.nome_taboa !='munips':
                uids_mod=conn_md.get_cursor().execute(str_mod.format(c.nome_enpaquete)).fetchall()
                uids_mod=[i[0] for i in uids_mod]
                if len(uids_mod)>0:
                    if len(uids_mod)==1:
                        uids_or=conn_or.get_cursor().execute(str_or.format(c.nome_enpaquete,'like',self._format_cons_uids(uids_mod))).fetchall()
                    else:
                        qr=str_or.format(c.nome_enpaquete,'in',f"({self._format_cons_uids(uids_mod)})")
                        uids_or=conn_or.get_cursor().execute(qr).fetchall()
                    if len(uids_or)>0:
                        uids_or=[i[0] for i in uids_or]
                        c.conservados.extend(uids_or)
                        c.get_diferencias()
                        if len(c.cambios)>0:
                            self.log.ok(f"Total de cambios Capa: {c.nome_taboa} ::: {len(c.cambios)}")
                            total = total+ len(c.cambios)
                        else:
                            self.log.info(f"{c.nome_taboa} Non se realizou ningun cambio")
                    else:
                        self.log.info(f"{c.nome_taboa} Ningun feature do modificado coincide co orixinal")
                else:
                    self.log.info(f"{c.nome_taboa} Non ten features")
            else:
                c.conservados.append(self.municipio)
                c.get_diferencias()
        self.num_actualizados=total
        conn_md.pecha()
        conn_or.pecha() 
        ## ATOPA AS DIFERENCIAS 
        self.log.ok(f"Total actualizados {self.num_actualizados}")
        return True
    def historial(self):
        self.get_municipio()
        self.obter_taboas()
        self.engadidos_totais()
        self.borrados_totais()
        self.actualizados_totais()
    def update(self):
        self.log.subseccion("Creacion novos")
        for c in self.lista_capas:
            c.crea_novos() 
        self.log.subseccion("Actualizacion atributos")
        for c in self.lista_capas:
            c.actualiza_att()
        self.log.subseccion("Actualizacion xeometrias")
        for c in self.lista_capas:
            c.actualiza_xeom()
        self.log.subseccion("Borrado")
        for c in self.lista_capas:
            c.borra()
def runstandalone():
    # print("EXecuta")

    modificado=DialogoArchivo().abre_gpkg("Selecciona paquete MODIFICADO")
    print(modificado)
    if modificado is None or modificado =='':
        iface.messageBar().pushMessage("Desempaquetado", "Cancelado", level=Qgis.Warning)
        return
    orixinal=DialogoArchivo().abre_gpkg("Selecciona paquete ORIXINAL")
    if orixinal is None or orixinal=='':
        iface.messageBar().pushMessage("Desempaquetado", "Cancelado", level=Qgis.Warning)
        return
    sincro=UnPack(orixinal,modificado)
    try:
        sincro.historial()
        sincro.update()
    finally:
        sincro.log.pecha()
    return sincro.pkg_mod
def runAcoplado(orixinal,modificado) -> UnPack:
    sincro=UnPack(orixinal,modificado)
    sincro.historial()
    sincro.update()
    return sincro

def run_con_fotos():
    ruta=runstandalone()
    if ruta:
        QMessageBox.information(iface.mainWindow(), "Sincronizacion", 'Desempaquetado realizado' )
        ruta_proxecto=Proxecto().carpeta_proxecto()
        ruta_c_qfield=Rutas.carpeta(sincronizacion.pkg_qfield_abs)
        tar=QgsTask.fromFunction('Sincro fotos',tarefa,on_finished=completado,ruta_proxecto=ruta_proxecto,ruta_c_qfield=ruta_c_qfield)
        QgsApplication.taskManager().addTask(tar)


def runtest():
    print("EXecuta")
    orixinal=r"C:\Users\sergio.botana\OneDrive - ApplusGlobal\PlanSaneamentoGalicia_UTE\300-SISTEMATIZACION_INFORMACION\03_INVENTARIO\PAQUETES_QFIELD\ORIXINAIS\27065_VILALBA\data.gpkg"
    modificado=r"C:\Users\sergio.botana\OneDrive - ApplusGlobal\PlanSaneamentoGalicia_UTE\300-SISTEMATIZACION_INFORMACION\03_INVENTARIO\PAQUETES_QFIELD\MODIFICADOS\27065_VILALBA\data.gpkg"
    # orixinal=r"C:\Users\sergio.botana\Desktop\banco_probas_des\PAQUETES_QFIELD\ORIXINAIS\15020_CARNOTA\data.gpkg"
    # modificado=r"C:\Users\sergio.botana\Desktop\banco_probas_des\PAQUETES_QFIELD\MODIFICADOS\15020_CARNOTA\data.gpkg"
    sincro=UnPack(orixinal,modificado)
    sincro.historial()
    sincro.update()

def desempaqueta():
    ruta=runstandalone()
    if ruta:
        QMessageBox.information(iface.mainWindow(), "Sincronizacion", 'Desempaquetado realizado' )
        ruta_proxecto=Proxecto().carpeta_proxecto()
        carpeta_qfield=Rutas.carpeta(ruta)
        # ruta_c_qfield=Rutas.carpeta(sincronizacion.pkg_qfield_abs)
        tar=QgsTask.fromFunction('Sincro fotos',qgis_task,on_finished=completado,ruta_proxecto=ruta_proxecto,ruta_c_qfield=carpeta_qfield)
        QgsApplication.taskManager().addTask(tar)


