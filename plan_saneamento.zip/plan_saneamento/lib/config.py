
class Configuracion:
    def __init__(self) -> None:
        pass
    def check_proxecto(self):
        pass 