from qgis.utils import iface
from qgis.PyQt.QtWidgets import *
from qgis.core import *

class ExcepcionCapas(Exception):
    def __init__(self,*args):
        if args:
            self.mensage=args[0]
        else:
            self.mensage=None
    def __str__(self):
        if self.mensage:
            return '{0}'.format(self.mensage)
        else:
            return 'Erro de usuario'


str_nome_proc="Filtro"

def lee_capa(cadea):
    cap=QgsProject.instance().mapLayersByName(cadea)
    len_cap=len(cap)
    print(len_cap)
    if len_cap>1:
        raise ExcepcionCapas("{} ------- Duplicada no TOC".format(cadea))
    else:
        if len_cap < 1 :
            raise ExcepcionCapas("{} ------- Non se atopa no TOC ".format(cadea))
    QgsMessageLog.logMessage("{} ------- Filtrada".format(cadea), str_nome_proc, level=Qgis.Success)
    return cap[0]

def capas_qgis(ls):
    capas=[]
    for c in ls:
        capas.append(lee_capa(c))
    return capas

class DialogoArchivo:
    def abre_dialogo(self,ext):
        filename = QFileDialog.getOpenFileName(iface.mapCanvas(), "Selecciona arquivo ","", ext)
        return filename[0]
    def abre_gpkg(self):
        return self.abre_dialogo('*.gpkg')


def abre_capa_gpkg(ruta_gpkg,nome):
    sufijo_capa='|%s'%nome
    punteiro_capa=ruta_gpkg + sufijo_capa
    vlayer = QgsVectorLayer(punteiro_capa, nome, "ogr")
    try:
        if not vlayer.isValid():
            raise Exception
    except:
        QMessageBox.information(iface.mainWindow(), "Error!", 'Capa %s non atopada'%nome )
    return vlayer

def garda_todolos_estilos():

    for layer in QgsProject.instance().mapLayers().values():
        lyr_name = layer.name()
        # If you don't test before if there is already an existing style
        # with the same name, QGIS will open a GUI asking you if you want
        # to overwrite
        
        layer.saveStyleToDatabase(
            f'qfield_{lyr_name}', 
            f'Estilo para qfield de {lyr_name}', 
            True, 
            '')

def lee_capa_emb(nome):
    cap=QgsProject.instance().mapLayersByName(nome)
    len_cap=len(cap)
    if len_cap>1:
        iface.messageBar().pushMessage("Aglomeracion", "Capa aglomeracions duplicada", level=Qgis.Warning)
        return
    else:
        if len_cap < 1 :
            iface.messageBar().pushMessage("Aglomeracion", "Non se atopa a capa aglomeracions", level=Qgis.Warning)
            return
        # QgsMessageLog.logMessage("{} ------- Filtrada".format(cadea), str_nome_proc, level=Qgis.Success)
    return cap[0]

