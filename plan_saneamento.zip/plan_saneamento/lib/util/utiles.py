from qgis.utils import iface
from qgis.PyQt.QtWidgets import QFileDialog
from qgis.core import *
from qgis.utils import iface
import os
import pathlib

class Rutas:
    @staticmethod
    def arquivo(ruta):
        return os.path.basename(ruta)
    @staticmethod
    def carpeta(ruta):
        return os.path.dirname(ruta)
    @staticmethod
    def extension(ruta):
        return pathlib.PurePosixPath(ruta).suffix
    @staticmethod
    def nome_sen_extension(ruta):
        return pathlib.PurePosixPath(ruta).stem



class Proxecto:
    def __init__(self):
        self.proxecto=QgsProject.instance()
        self.nome_arquivo()
        self.carpeta_proxecto()
        self.get_ruta()
    def nome_arquivo(self):
        self.arquivo = os.path.basename(self.proxecto.fileName())
        return self.nome_arquivo
    def carpeta_proxecto(self):
        self.carpeta=os.path.dirname(self.proxecto.fileName())
        return self.carpeta
    def get_ruta(self):
        self.ruta=self.proxecto.fileName()
    def get_variable(self,var):
        return QgsExpressionContextUtils.projectScope(self.proxecto).variable(f"{var}")
    def set_variable(nome,valor):
        QgsExpressionContextUtils.setProjectVariable(nome,valor)

class DialogoArchivo:
    last_folder=None 
    def abre_dialogo(self,msg,ext):
        if DialogoArchivo.last_folder and os.path.exists(DialogoArchivo.last_folder):
            carpeta=DialogoArchivo.last_folder 
        else:
            carpeta=Proxecto().carpeta
        filename = QFileDialog.getOpenFileName(iface.mapCanvas(), msg,carpeta, ext)
        carp=str(pathlib.PurePath(filename[0]).parent)
        DialogoArchivo.last_folder=carp
        return filename[0]
    def abre_gpkg(self,msg):
        return self.abre_dialogo(msg,'data.gpkg')

class Mensaxe:
    ERRO=Qgis.Critical
    ADVERTENCIA=Qgis.Warning
    EXITO=Qgis.Success
    INFO=Qgis.Info
    NIVEIS={Qgis.Critical:"ERRO",Qgis.Warning:"ADVERTENCIA",Qgis.Success:"OK",Qgis.Info:"INFO"}
    def __init__(self,pestana):
        self.pestana=pestana
    def ok(self,msg):
        iface.messageBar().pushMessage(self.pestana, msg, level=Mensaxe.EXITO)

    def ko(self,msg):
        iface.messageBar().pushMessage(self.pestana,msg, level=Mensaxe.ERRO)

    def coidado(self,msg):
        iface.messageBar().pushMessage(self.pestana,msg, level=Mensaxe.ADVERTENCIA)

    def info(self,msg):
        iface.messageBar().pushMessage(self.pestana, msg, level=Mensaxe.INFO)


class LogQgis:
    ERRO=Qgis.Critical
    ADVERTENCIA=Qgis.Warning
    EXITO=Qgis.Success
    INFO=Qgis.Info
    NIVEIS={Qgis.Critical:"ERRO",Qgis.Warning:"ADVERTENCIA",Qgis.Success:"OK",Qgis.Info:"INFO"}
    def __init__(self,pestana):
        self.pestana=pestana
    def ok(self,msg):
        QgsMessageLog.logMessage(msg, self.pestana, LogQgis.EXITO)
    def ko(self,msg):
        QgsMessageLog.logMessage(msg, self.pestana, LogQgis.ERRO)
    def coidado(self,msg):
        QgsMessageLog.logMessage(msg, self.pestana, LogQgis.ADVERTENCIA)
    def info(self,msg):
        QgsMessageLog.logMessage(msg, self.pestana, LogQgis.INFO)

    def savelog(self, ruta):
        self.arquivo_log=ruta 
        QgsApplication.messageLog().messageReceived.connect(self.writelogmessage)
    def writelogmessage(self,message, tag, level):
        with open(self.arquivo_log, 'a') as logfile:
            logfile.write('[{}]  -- [{}] -- : {}\n'.format(tag, LogQgis.NIVEIS[level], message))
    def pecha(self):
        QgsApplication.messageLog().messageReceived.disconnect(self.writelogmessage)

    def seccion(self,nome):
        st="""
        ########################################################
        {}
        ########################################################
        """
        st=st.format(nome)
        QgsMessageLog.logMessage(st, self.pestana, LogQgis.INFO)
        return st
    def subseccion(self,nome):
        st="""
        --------------------------------------------------------
        {}
        --------------------------------------------------------
        """
        st=st.format(nome)
        QgsMessageLog.logMessage(st, self.pestana, LogQgis.INFO)
        return st