import ftplib
class ConfFTP:
    FTP_HOST = r"158.69.250.93"
    FTP_USER = "psg"
    FTP_PASS = "pl4ns4ng4l"

    def __init__(self) -> None:
        pass
    def conectar(self):
        self.ftp=ftplib.FTP(ConfFTP.FTP_HOST,ConfFTP.FTP_USER,ConfFTP.FTP_PASS)
        self.ftp.encoding="utf-8"
        return True
    def sube_arquivo(self,ruta,nome):
        with open(ruta,"rb") as arquivo:
            self.ftp.storbinary(f"STOR {nome}",arquivo)
        return True
    def pecha_conexion(self):
        self.ftp.close()