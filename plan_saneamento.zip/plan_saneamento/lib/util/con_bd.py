import psycopg2 as ps
import sqlite3
from qgis.utils import iface
from .utiles import LogQgis
from osgeo import ogr
import os
#### PROD
HOST='51.103.42.170'
PORT=5432
DB='galicia_infraestructuras'
USER='postgres'
PASS='Applus01$'

### TESTS
# HOST='127.0.0.1'
# PORT=5432
# DB='gal_infra'
# USER='postgres'
# PASS='abc123'
# STR_CONN='{},{},{},{},{}'.format(HOST,PORT,USER,PASS,DB)

class ConnBD:
    conn=None
    def __init__(self) -> None:
        self.host=HOST
        self.dbname=DB
        self.user=USER
        self.password=PASS
        self.port=PORT
        self.str_conn=self.get_string()
    def get_string(self) ->str:
        return "host={} dbname={} user={} password={} port={}".format(self.host,self.dbname,self.user,self.password,self.port)
    def get_cursor(self):
        if ConnBD.conn is None:
            # LogQgis("BD").info("Conectando")
            ConnBD.conn=ps.connect(self.str_conn)
        self.cusor=ConnBD.conn.cursor()
        # LogQgis("BD").info("Cursor obtido")
        return self.cusor
    # def pecha(self):
    #     self.cusor.close()
    @staticmethod
    def pecha_conexion():
        if ConnBD.conn:
            # LogQgis("BD").info("Pechando")
            ConnBD.conn.close()
            ConnBD.conn=None

class OGRPostGis:
    def __init__(self):
        self.str_conn="PG: host={} dbname={} user={} password={}".format(HOST,DB,USER,PASS)
    def abre_ds(self):
        self.conn= org.Open(self.str_conn)

        return True
    def pecha_ds(self):
        del self.conn
        return True
class OgrGpkg:
    def __init__(self,ruta):
        self.str_conn=ruta
        self.ds=None
    def abre_ds_lectura(self):
        self.ds= ogr.Open(self.str_conn,0)
        if self.ds is None:
            LogQgis("Lectura").ko("Non se atopa {}".format(self.str_conn))
            raise Exception("Non se atopa o ds")
        return True
    def abre_ds_escritura(self):
        self.ds=ogr.Open(self.str_conn,1)
        return True
    def pecha_ds(self):
        if self.ds:
            del self.ds
            return True
class ConnSqlite:
    def __init__(self,ruta):
        if os.path.exists(ruta):
            self.conn= sqlite3.connect(ruta)
        else:
            raise Exception("NON EXISTE A BD")
    def get_cursor(self):
        return self.conn.cursor()
    def pecha(self):
        self.conn.close()


