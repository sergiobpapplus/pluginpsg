from typing import Dict
from .util.con_bd import *
from .util.utiles import LogQgis
import traceback

# a = None 
# a=str([1,2,3])
# b="'{"
# c="}'"
# fn=b+a.replace('[','').replace(']','')+c
# print(fn)
# if type([]) is list :
#     print(str([1,2,3]))
# s='{1,2,3}'

# c=s.replace('{','').replace('}','').split(',')

# ls=[]

# for i in c:
#     print(i)
#     try:
#         ls.append(int(i))
#     except:
#         pass 

# print (ls)

def parse_valor_sql(valor):
    if type(valor) is float:
        valor=valor
    elif type(valor) is int:
        valor=valor
    elif type(valor) is bool:
        if valor:
            valor=1
        else:
            valor="null"
    elif type(valor) is str:
        valor=f"\'{valor}\'"
    elif valor is None or valor=='{}':
        return None 
    else:
        print(valor)
        raise Exception
    return valor

def casilla(celda):
    if celda.value == 'X':
        return True
    else:
        return False 
def casilla_vf(celda):
    if celda.value=='SI':
        return True 
    elif celda.value=='NON':
        return False 
    else:
        return None 
def get_comentario(celda):
    com=None
    try:
        com=celda.comment.text
    except:
        pass 
    return com
def casillasN(celda,el:int,ls):
    if casilla(celda):
        ls.append(el)
    return ls 

class DTOBase:
    def __init__(self,row,log:LogQgis) -> None:
        self.row=row
        self.codigo=None 
        self.nomecodigo=None
        self.nometaboa=None
        self.log=log
        self.uid=None 
    def parse_valor(self,k,v):
        cadea=None
        value=parse_valor_sql(v)
        if value is not None and value != '':
            cadea=f"{k} = {value}"
        return cadea
    def _update(self,con:ConnBD,qr):
        try:
            cur_pg=con.get_cursor()
            cur_pg.execute(qr)
            if cur_pg.rowcount>0:
                ConnBD.conn.commit()
                self.log.ok(f"Actualizado {self.codigo} - {self.nometaboa}")
            else:
                self.log.ko(f"Non actualizado {self.codigo} - {self.nometaboa}")
        except Exception:
            self.log.ko(traceback.format_exc())
            self.log.ko(f"Non actualizado excepcion {self.codigo} - {self.nometaboa}")
            self.log.ko(f"{qr}")
            raise 
        finally:
            if cur_pg:
                cur_pg.close()

    def update_safe(self,conn:ConnBD):
        uid=self.check_cod(conn)
        qr="update datos_psg.{} set {} where uuid = '{}'"
        qr_chk="select {},int_notas,int_excel from datos_psg.{} where uuid='{}'"
        qr_set="{}"
        dcc= self.get_dict()
        for k,v in dcc.items():
            self.log.info(f"Valor : {v}")
            val=parse_valor_sql(v)
            if val is not None:
                qr_chk=qr_chk.format(k,self.nometaboa,uid)
                res_chk=self.select(conn,qr_chk)
                if (res_chk[0][0] is None or res_chk[0][0] != '{}')  and res_chk[0][2]!=1:
                    qr=qr.format(self.nometaboa, f"{k} = {val},int_excel=1",uid)
                    self.log.ok("Dato non existente")
                    # self._update(conn,qr)
                elif res_chk[0][2]!=1:
                    self.log.coidado(f"Dato existente --- {self.codigo} - {self.nometaboa}")
                    nota=res_chk[0][1]
                    if nota is None:
                        nota=''
                    qr_set=f"'{nota}+' #$(D.N.I.D Concello : {k} - {val})$#' "
                    qr=qr.format(self.nometaboa,f"int_notas={qr_set},int_excel=1",uid)
                    self.log.info(f"{qr}")
                else:
                    self.log.ko(f"OMITESE ACTUALIZACIÓN, EXCEL XA CARGADO --- {self.codigo} - {self.nometaboa}")
                    # self._update(conn,qr)

    def update(self,conn):
        qr="update datos_psg.{} set {} where uuid = '{}'"
        try:
            uid=self.check_cod(conn)
            if uid is None :
                self.log.ko(f"Non se atopa id : {self.codigo} - {self.nometaboa}")
                return
            str_set=self.dict_to_set(self.get_dict())

            qr=qr.format(self.nometaboa,str_set,uid)
            self._update(conn,qr)
        except Exception:
            self.log.ko(traceback.format_exc())
            self.log.ko(f"Non actualizado excepcion {self.codigo} - {self.nometaboa}")
            self.log.ko(f"{qr}")
            raise 

            
    def select(self,con,qr):
        try:
            cur_pg=con.get_cursor()
            cur_pg.execute(qr)
            res=cur_pg.fetchall()
        except:
            self.log.ko(traceback.format_exc())
            self.log.ko(f"{qr}")
            raise
        finally:
            if cur_pg:
                cur_pg.close()
        return res
    def check_cod(self,con):
        qr="select uuid from datos_psg.{} where {} = '{}'"
        qr=qr.format(self.nometaboa, self.nomecodigo, self.codigo)
        uid=self.select(con,qr)
        if len(uid)>1:
            self.log.ko(f"O codigo do elemento esta duplicado : {self.codigo} - {self.nometaboa}")
            return
        elif len(uid) == 0 : 
            self.log.ko(f"Non existe o codigo na BD : {self.codigo} - {self.nometaboa}")
            return
        self.uid=uid[0][0]
        return self.uid
        # try:
        #     cur_pg=conn.get_cursor()
        #     cur_pg.execute(sql)
        #     chk_uid=cur_pg.fetchall()
        # finally:
        #     if cur_pg:
        #         cur_pg.close()

        #     ConnBD.pecha_conexion()
        # self.uid=chk_uid
        # return self.uid
    def dict_to_set(self,dcc:Dict):
        cadea=''
        i=0

        for k,v in dcc.items():
            
            value=parse_valor_sql(v)
            if v is not None and i == 0 :
                cadea=f"{k} = {value}"
                i+=1
            elif value is None or value == '':
                pass 
            elif value is not None and i > 0:
                cadea=f"{cadea}, {k} = {value}"
                i=+1
            # self.log.info(f"{cadea}")
        if cadea == '':
            return None 
        else:
            return cadea



    def tofieldarray(self,ls) -> str:
        a="'{"
        i=0
        for x in ls:
            if i == 0 :
                a=a + str(x)
            else:
                a=a + ','+ str(x)
            i+=1
        a= a + "}'"
        return a 
    def get_dict(self) -> Dict:
        dc=self.__dict__.copy()
        del dc['row']
        del dc['codigo']
        del dc['nomecodigo']
        del dc['nometaboa']
        del dc['log']
        del dc['uid']
        return dc 
    def get_mn(self):
        pass 
class TTORMDTO(DTOBase):
    def __init__(self,row,log) -> None:
        super().__init__(row,log)
        self.nomecodigo='codtt'
        self.nometaboa='ttormps'
        self.codigo=self.row[1].value
        self.capacidad=self.row[5].value
        self.pottotinst=self.row[6].value
        self.conselectanual=self.row[7].value
        pret={
            "Non":1,
            "Grosos":2,
            "Ceston":3,
            "Manual":4,
            "Automatica":5,
            "Areneiro":7
        }
        self.pret=[]
        if casilla(self.row[8]):
            self.pret.append(pret['Non'])
        if casilla(self.row[9]):
            self.pret.append(pret['Grosos'])
        if casilla(self.row[10]):
            self.pret.append(pret['Areneiro'])
        if casilla(self.row[11]):
            self.pret.append(pret['Ceston'])
        if casilla(self.row[12]):
            self.pret.append(pret['Manual'])
        if casilla(self.row[13]):
            self.pret.append(pret['Automatica'])
        self.el_saida=[]
        saida={
            "Comporta":1,
            "Vortex":2,
            "Bombeo":3,
            "Non":4
        }
        if casilla(self.row[14]):
            self.el_saida.append(saida['Comporta'])
        if casilla(self.row[15]):
            self.el_saida.append(saida['Vortex'])
        if casilla(self.row[16]):
            self.el_saida.append(saida['Bombeo'])
        if casilla(self.row[17]):
            self.el_saida.append(saida['Non'])
        self.trat=[]
        trat={
            "Reixa":1,
            "Malla":2,
            "Deflector":3,
            "Non":4
        }
        self.trat=casillasN(row[18],trat['Non'],self.trat)
        self.trat=casillasN(row[19],trat['Reixa'],self.trat)
        self.trat=casillasN(row[20],trat['Malla'],self.trat)
        self.trat=casillasN(row[21],trat['Deflector'],self.trat)
        self.limp=[]
        limp={
            "Non":1,
            "Basculantes":2,
            "Manual":3,
            "Outro":4
        }
        self.limp=casillasN(row[22],limp['Basculantes'],self.limp)
        self.limp=casillasN(row[23],limp['Manual'],self.limp)
        self.limp=casillasN(row[25],limp['Outro'],self.limp)
        self.limp=casillasN(row[26],limp['Non'],self.limp)
        tel={
            "Non":1, 
            "Alarmas":2,
            "Remoto":3
        }
        self.tel=[]
        self.tel=casillasN(row[27],tel['Non'],self.tel)
        self.tel=casillasN(row[28],tel['Alarmas'],self.tel)
        self.tel=casillasN(row[27],tel['Remoto'],self.tel)
        prob={
            "Entrada":6,
            "Pretratamento":9,
            "Regulacion":10,
            "Limpeza":11,
            "Outros":12,
            "Non":13
        }
        self.prob=[]
        self.prob=casillasN(row[30],prob['Entrada'],self.prob)
        self.prob=casillasN(row[31],prob['Pretratamento'],self.prob)
        self.prob=casillasN(row[32],prob['Regulacion'],self.prob)
        self.prob=casillasN(row[33],prob['Limpeza'],self.prob)
        self.prob=casillasN(row[34],prob['Outros'],self.prob)
        self.prob=casillasN(row[35],prob['Non'],self.prob)
    def get_dict(self) -> Dict:
        dc = super().get_dict()
        del dc['prob']
        del dc['tel']
        del dc['limp']
        del dc['trat']
        del dc['el_saida']
        del dc['pret']

        
class BOMBDTO(DTOBase):
    def __init__(self,row,log) -> None:
        super().__init__(row,log)
        self.log=log
        self.nomecodigo='codbomb'
        self.nometaboa='bombps'
        self.codigo=self.row[1].value
        self.potinst=self.row[5].value
        self.conselect=self.row[6].value
        self.qbomb=self.row[7].value
        self.hbomb=self.row[8].value
        self.nbombpf=self.row[9].value
        self.nbombres=self.row[10].value
        self.horasfunc=self.row[11].value 
        self.volanualbom=self.row[12].value
        pret={
            "Non":1,
            "Pozo":2,
            "Arenero":3,
            "Cesto":4,
            "Reixa Manual":5,
            "Reixa Automatica":6
        } 
        self.pret=[]
        if casilla(self.row[13]):
            self.pret.append(pret['Non'])
        if casilla(self.row[14]):
            self.pret.append(pret['Pozo'])
        if casilla(self.row[15]):
            self.pret.append(pret['Arenero'])
        if casilla(self.row[16]):
            self.pret.append(pret['Cesto'])
        if casilla(self.row[17]):
            self.pret.append(pret['Reixa Manual'])
        if casilla(self.row[18]):
            self.pret.append(pret['Reixa Automatica'])
        prot={
            "Desconocido":1,
            "Calderin":2,
            "Antiariete":3,
            "Variador":4,
            "Arrancador":5,
            "Non":7,
            "Reixa automática":6
        }
        self.disp_prot=[]
        if casilla(self.row[19]):
            self.disp_prot.append(prot['Non'])
        if casilla(self.row[20]):
            self.disp_prot.append(prot['Calderin'])
        if casilla(self.row[21]):
            self.disp_prot.append(prot['Antiariete'])
        if casilla(self.row[22]):
            self.disp_prot.append(prot['Variador'])
        if casilla(self.row[23]):
            self.disp_prot.append(prot['Arrancador'])
        if casilla(self.row[25]):
            self.disp_prot.append(prot['Reixa automática'])
        self.telecontrol=[]
        tel={
            "Non":1,
            "Alarmas":2,
            "Remoto":3
        }
        if casilla(self.row[26]):
            self.telecontrol.append(tel['Non'])
        if casilla(self.row[27]):
            self.telecontrol.append(tel['Alarmas'])
        if casilla(self.row[28]):
            self.telecontrol.append(tel['Remoto'])

        self.prob=[]
        prob={
            "Carga":2,
            "Ariete":1,
            "Valvula":7,
            "Reixa":5,
            "Arrancadores":4,
            "No":6,
        }
        if casilla(self.row[29]):
            self.prob.append(prob['Carga'])
        if casilla(self.row[30]):
            self.prob.append(prob['Ariete'])
        if casilla(self.row[31]):
            self.prob.append(prob['Valvula'])
        if casilla(self.row[32]):
            self.prob.append(prob['Arrancadores'])
        if casilla(self.row[33]):
            self.prob.append(prob['Reixa'])
        if casilla(self.row[34]):
            self.prob.append(prob['No'])
    def get_dict(self) -> Dict:
        dcc = super().get_dict()
        del dcc['prob']
        del dcc['disp_prot']
        del dcc['pret']
        del dcc['telecontrol']
        return dcc 


class PROBDTO:
    def __init__(self, problema, descripcion) -> None:

        self.problema=problema 
        self.descripcion=descripcion




class EDARDTO (DTOBase):
    def __init__(self,row,log) -> None:
        super().__init__(row,log)
        self.codigo=self.row[1].value
        self.nomecodigo='codedar'
        self.nometaboa='edarps'
        try:
            self.fangaoutratexto=self.row[17].comment.text
        except:
            self.fangaoutratexto=None
        try:
            self.fangosxestor=self.row[19].comment.text
        except:
            self.fangosxestor=None

        self.conselect=self.row[6].value

        self.potinstal=self.row[5].value 

        self.consreact=self.row[7].value

        self.int_heq=self.row[9].value

        self.int_q=self.row[10].value 
        float(self.int_q)

        fosas=casilla(self.row[23]) 
        edar=casilla(self.row[25])   
        if fosas and edar:
            self.fangdest_id=3 
        elif fosas:
            self.fangdest_id=1 
        elif edar:
            self.fangdest_id=2 
        else:
            self.fangdest_id= None 
   
        self.cantlodsal=self.row[16].value 

        self.cantlodtrat=self.row[22].value

        self.prodresiduos=self.row[8].value

        self.qptapret=self.row[11].value

        self.qptasecund=self.row[12].value

        self.qmediotratado=self.row[13].value

        self.qabasted=self.row[15].value

        self.abasted=casilla_vf( self.row[14])
        self.abasted= 1 if self.abasted else 0

        self.distatrat=self.row[21].value
        self.problemas=self._get_problemas()
    def _get_problemas(self):
        probs={
            "Pretratamento":1,
            "Bioloxico":2,
            "Desinfeccion":3,
            "Fangos":4,
            "Sen problemas":5,
            "Sen datos":6
        }
         #pret
        prob=[]
        if casilla(self.row[26]):
            prob.append(PROBDTO(
                 problema=probs['Pretratamento'],
                 descripcion=get_comentario(self.row[26])
             ))
        if casilla(self.row[27]):
            prob.append(PROBDTO(
                problema=probs['Bioloxico'],
                descripcion=get_comentario(self.row[27])
            ))
        if casilla(self.row[28]):
            prob.append(PROBDTO(
                problema=probs['Desinfeccion'],
                descripcion=get_comentario(self.row[28])
            ))
        if casilla(self.row[29]):
            prob.append(PROBDTO(
                problema=probs['Fangos'],
                descripcion=get_comentario(self.row[29])
            ))
        if casilla(self.row[30]):
            prob.append(PROBDTO(
                problema=probs['Sen problemas'],
                descripcion=get_comentario(self.row[30])
            ))
        if casilla(self.row[31]):
            prob.append(PROBDTO(
                problema=probs['Sen datos'],
                descripcion=get_comentario(self.row[31])
            ))






        