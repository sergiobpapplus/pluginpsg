from operator import le
from typing import List
from openpyxl import Workbook,load_workbook
from lib_aux.utiles import Proxecto,LogQgis
from lib_aux.con_bd import ConnBD
import re 
import os
from qgis.utils import iface
import urllib 
import json 
from PyQt5.QtCore import QVariant



class Elemento:
    plantilla:Workbook=None
    def __init__(self,concello,log) -> None:
        self.concello=concello 
        self.log:LogQgis=log
        self.tipo="Point"
        self.nome="Bombeos"
        self.ls_datos=[]
    def query_ex(self):
        self.log.info("Consulta")
        conn=ConnBD()
        try:
            cur_pg=conn.get_cursor()
            cur_pg.execute(self.cons_ex)
            self.ls_datos=cur_pg.fetchall()
            self.log.info("Executada")
        finally:
            if cur_pg:
                cur_pg.close
            ConnBD.pecha_conexion()
        self.log.info(f"{self.ls_datos}")

    def export_kml(self,carpeta):
        self.query_ex()
        self.layer = QgsVectorLayer(f"{self.tipo}?crs=epsg:4286", self.nome, "memory")
        self.provider = self.layer.dataProvider()
        # add fields
        self.provider.addAttributes([QgsField("Name", QVariant.String),
                            QgsField("Codigo",  QVariant.String),
                            QgsField("Nome",  QVariant.String)])
        self.layer.updateFields() # tell the vector layer to fetch changes from the provider
        for x in self.ls_datos:
            self.log.info(f"{x}")
            fet = QgsFeature()
            fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x[0],x[1])))
            fet.setAttributes([f"{x[2]} - {x[3]}", x[2], x[3]])
            self.provider.addFeatures([fet])
            self.layer.updateExtents()
        kml=f"{self.concello}_{self.nome}.kml"
        ruta=os.path.join(carpeta,kml)
 
        QgsVectorFileWriter.writeAsVectorFormat(layer=self.layer,fileName = ruta, fileEncoding ="utf-8", driverName ="KML")


class KMLEDAR(Elemento):
    def __init__(self,concello,log) -> None:
        super().__init__(concello, log)
        self.tipo="Point"
        self.nome="EDAR"
        self.cons_ex="""select  ST_X(ST_Transform(ed.geom, 4326)), ST_Y(ST_Transform(ed.geom,4326 )),ed.codedar,ed.nombre
        from datos_psg.edarps ed join datos_psg.parroquiasps pa on pa.codigo=ed.fkparroquia where ed.fkmunicod={} and (int_borra is null or int_borra !=1) and fkaglomuuid is not null """
        self.cons_ex=self.cons_ex.format(self.concello)
        self.log.info(f"{self.cons_ex}")

class KMLBombeo(Elemento):
    def __init__(self, concello, log) -> None:
        super().__init__(concello, log)
        self.tipo="Point"
        self.nome="Bombeos"
        self.cons_ex=""" select ST_X(ST_Transform(bo.geom, 4326)), ST_Y(ST_Transform(bo.geom,4326 )),bo.codbomb,bo.nombre
        from datos_psg.bombps bo join datos_psg.parroquiasps pa on pa.codigo=bo.fkparroquia where bo.fkmunicod={}and (bo.int_borra !=1 or bo.int_borra is null) and fkaglomuuid is not null"""
        self.cons_ex=self.cons_ex.format(self.concello)
        self.log.info(f"{self.cons_ex}")


class KMLTanques(Elemento):
    def __init__(self, concello, log) -> None:
        super().__init__(concello, log)
        self.tipo="Point"
        self.nome="Tanques"
        self.cons_ex="""select ST_X(ST_Transform(tt.geom, 4326)), ST_Y(ST_Transform(tt.geom,4326 )),tt.codtt,tt.nombre
        from datos_psg.ttormps tt join datos_psg.parroquiasps pa on pa.codigo=tt.fkparroquia where tt.fkmunicod={} and (tt.int_borra !=1 or tt.int_borra is null)"""
        self.cons_ex=self.cons_ex.format(self.concello)
        self.log.info(f"{self.cons_ex}")






def get_nom_concello(codine):
    qr_nome_concello=""" select nombre from datos_psg.munips where codmuni = {}""".format(codine)
    conn=ConnBD()
    try:
        cur_pg=conn.get_cursor()
        cur_pg.execute(qr_nome_concello)
        nom_cnc=cur_pg.fetchall()[0]
    finally:
        if cur_pg:
            cur_pg.close()

        ConnBD.pecha_conexion()
    return nom_cnc

def xera_kmls():
    ruta_prox=Proxecto().carpeta_proxecto()
    log=LogQgis("KML")
    codine=Proxecto().get_variable('concello')
    ed=KMLEDAR(codine,log)
    bo=KMLBombeo(codine,log)
    tt=KMLTanques(codine,log)
    ed.export_kml(ruta_prox)
    bo.export_kml(ruta_prox)
    tt.export_kml(ruta_prox)
    iface.messageBar().pushMessage("KML", "KMLs xerados", level=Qgis.Success)

    # nome_conc=get_nom_concello(codine)








