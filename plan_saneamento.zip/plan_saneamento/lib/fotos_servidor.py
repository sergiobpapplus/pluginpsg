import os
# from qgis.core import *
import re 
from PyQt5.QtWidgets import QMessageBox
from .util.con_bd import ConnBD
from .util.con_ftp import ConfFTP
from .util.utiles import LogQgis,Proxecto,DialogoArchivo
import pathlib
from PIL import Image
from qgis.utils import iface
from qgis.PyQt.QtWidgets import QFileDialog
import datetime
from qgis.core import QgsApplication, QgsTask, QgsMessageLog, Qgis
class DialogoCarpeta(DialogoArchivo):
    # def abre_dialogo(self,msg,ext):
    #     filename = QFileDialog.getOpenFileName(iface.mapCanvas(), msg,Proxecto().carpeta, ext)
    #     return filename[0]
    # def abre_gpkg(self,msg):
    #     return self.abre_dialogo(msg,'*.gpkg')
    def abre_carpeta(self):
        if DialogoArchivo.last_folder and os.path.exists(DialogoArchivo.last_folder):
            carp=DialogoArchivo.last_folder 
        else:
            carp=Proxecto().carpeta
        carpeta=QFileDialog.getExistingDirectory(iface.mapCanvas(), "Selecciona carpeta",carp)
        if carpeta:
            DialogoArchivo.last_folder=carpeta 
        return carpeta


class LogFotos(LogQgis):
    def savelog(self, ruta):
        now = datetime.datetime.now()
        arquivo=f'sincro_fotos_{now.year}_{now.month}_{now.day}_{now.hour}_{now.minute}_{now.second}.log'
        ruta_log=os.path.join(ruta,arquivo)
        super().savelog(ruta_log)




def resize_image(or_path,dest_path,qual=96):
    im=Image.open(or_path)
    im.save(dest_path,optimize=True,quality=qual)


class Config_Querys:
    bb='bombpsfoto'
    ed='edarpsfotos'
    ttorm='ttormpsfoto'
    mun='munipsfotos'
    SERVIDOR='http://infra.appluscorp.com/psg/inventario/fotos/'
    str_q_edar="""
    select ed.fkmunicod , e.ruta , e.url, e.uuid 
    from datos_psg.edarpsfotos e 
    join datos_psg.edarps ed on ed.uuid = e.uuidedar 
    where e.url is null and e.ruta {}
    """
    str_q_bomb="""
    select b.fkmunicod , bf.ruta ,bf.url ,bf.uuid 
    from datos_psg.bombpsfoto bf
    join datos_psg.bombps b on b.uuid = bf.fkbombuuid 
    where bf.url is null and bf.ruta {}
    """
    str_q_ttorm="""
    select t.fkmunicod, ttf.ruta, ttf.url,ttf.uuid 
    from datos_psg.ttormpsfoto ttf
    join datos_psg.ttormps t on t.uuid= ttf.fkttormuuid
    where ttf.url is null and ttf.ruta {}
    """
    str_q_munifot="""
    select m.codmuni , mf.ruta ,mf.url , mf.uuid 
    from datos_psg.munipsfotos mf
    join datos_psg.munips m on m.codmuni =mf.fkmunicod 
    where mf.url is null and mf.ruta {}
    """
## RUTA PROXECTO

    ## RELATIVA QFIELD
    fotos_qfield='DCIM'
    ## RELATIVA REPO LOCAL 
    fotos_lect_proxecto='IMAXES'
    fotos_temp_proxecto='DCIM'
    def __init__(self,carp_bas,carp_qfield) -> None:
        self.carpeta_base=carp_bas
        self.carpeta_base_qfield=carp_qfield
        self.carpeta_fotos_qfield=os.path.join(self.carpeta_base_qfield,Config_Querys.fotos_qfield)
        self.carpeta_lect_proxecto=os.path.join(self.carpeta_base,Config_Querys.fotos_lect_proxecto)
        self._check_carpetas()
        self.log=LogFotos("FOTOS")
        if not os.path.exists(self.carpeta_fotos_qfield):
            self.log.savelog(self.carpeta_base_qfield)
        else:
            self.log.savelog(self.carpeta_fotos_qfield)
        
    def _check_carpetas(self):

        if not os.path.exists(self.carpeta_lect_proxecto):
            os.makedirs(self.carpeta_lect_proxecto)
        return True


    def lee_carpeta(self):
        self.log.seccion("Lectura de contido carpeta")
        if not os.path.exists(self.carpeta_fotos_qfield):
            self.log.coidado("Non hai fotos ou non estan na carpeta DCIM")
            return False
        #LISTADO DAS FOTOS "TEMPORAIS"
        self.fotos_campo={}
        #COMPLETA:RELATIVA
        for raiz, carpetas, arquivos in os.walk(self.carpeta_fotos_qfield):
            for a in arquivos:
                abs=os.path.join(raiz,a)
                rel=os.path.relpath(abs,self.carpeta_base_qfield)
                self.fotos_campo[abs]=pathlib.PurePath(rel).as_posix()
        if len(self.fotos_campo)==0:
            self.log.ko("Sin elementos na carpeta")
            return False
        self.fixa_where()
        self.numero_fotos=len(self.fotos_campo)
        self.log.info(f'Total de fotos en carpeta : {len(self.fotos_campo)}')
        return True
    def fixa_where(self):
## FIXAR WHERE
        if len(self.fotos_campo)<2:
            where_2='={}'
        elif len(self.fotos_campo)>=2:
            where_2= 'in ({})'
        else:
            where_2=None
        self.where_2= where_2
        # self.log.info("Where 2 : {}".format(self.where_2))
        self.cons_consulta()
        return self.where_2 
    def cons_consulta(self):
        i= 0 
        ## CONSTRUE CLAUSULA
        ls_to_query=''
        for f in self.fotos_campo.values():

            if i!=0:
                ls_to_query=ls_to_query+","
            ls_to_query=ls_to_query+"\'"+ f + "\'"
            i=i+1
        self.where=self.where_2.format(ls_to_query)
        # self.log.info("Where : {}".format(self.where))
        return self.where
    def consultas(self):
        self.log.seccion("Execucion de consultas")
        res=False
        # CONSULTAS
        try:
            conn= ConnBD()
            cur=conn.get_cursor()
        #    print(str_q_edar.format(str_1))
            qq=self.str_q_edar.format(self.where)
            cur.execute(qq)
            self.res_edar=cur.fetchall()
            if self.res_edar and len(self.res_edar)>0:
                self.log.info(f" Total de fotos de EDAR {len(self.res_edar)}")
                res=True
            else:
                self.log.info("Non se atoparon fotos de EDAR vinculadas")
        except Exception as e:
            # self.log.ko(qq)
            self.log.ko("Erro no select de EDAR")
            self.log.ko("{}".format(e))
            res= False
            raise
        finally:
            cur.close()
            ConnBD.pecha_conexion()
        try:
            conn=ConnBD()
            cur=conn.get_cursor()
            qq=self.str_q_bomb.format(self.where)
            # self.log.info(f'Consulta fotos Bombeo : \n {qq}')
            cur.execute(qq)
            self.res_bomb=cur.fetchall()
            if self.res_bomb and len(self.res_bomb) > 0:
                self.log.info(f" Total de fotos de Bombeos {len(self.res_bomb)}")
                res=True
            else:
                self.log.info("Non se atoparon fotos de Bombeos vinculadas")
        except Exception as e:
            # self.log.ko(qq)
            self.log.ko("Erro no select de bombeos")
            self.log.ko("{}".format(e))
            res = False
            raise
        finally:
            cur.close()
            ConnBD.pecha_conexion()
        try:
            conn=ConnBD()
            cur=conn.get_cursor()
            qq=self.str_q_ttorm.format(self.where)
            # self.log.info(f'Consulta fotos TT : \n {qq}')
            cur.execute(qq)
            self.res_ttorm=cur.fetchall()
            if self.res_ttorm and len(self.res_ttorm)>0:
                self.log.info(f" Total de fotos de Tanques de tormentas {len(self.res_ttorm)}")
                res=True
            else:
                self.log.info("Non se atoparon fotos de Tanques de tormentas vinculadas")
        except Exception as e:
            # self.log.ko(qq)
            self.log.ko("Erro select TTorm")
            self.log.ko("{}".format(e))
            res = False
            raise
        finally:
            cur.close()
            ConnBD.pecha_conexion()

        try:
            conn=ConnBD()
            cur=conn.get_cursor()
            qq=self.str_q_munifot.format(self.where)
            # self.log.info(f'Consulta fotos Mun : \n {qq}')
            cur.execute(qq)
            self.res_mun=cur.fetchall()
            if self.res_mun and self.res_mun>0:
                self.log.info(f" Total de fotos de libres {len(self.res_mun)}")
                res=True
            else:
                self.log.info("Non se atoparon fotos libres vinculadas")
        except Exception as e:
            # self.log.ko(qq)
            self.log.ko("Erro select Fotos municipio")
            self.log.ko("{}".format(e))
            res = False
            raise
        finally:
            cur.close()
            ConnBD.pecha_conexion()
        return res
    def _format_nome(self,etiqueta,baseact,mun):
        partes=baseact.split('_')
        if len(partes)>2 and re.match('\d{5}',partes[1]) and re.match(etiqueta,partes[0]):
            novo_nome=partes[1] + '_' + partes[0]
            for p in partes[2:]:
                novo_nome=novo_nome+'_'+p 
        elif len(partes)>2 and re.match('\d{5}',partes[0]) and re.match(etiqueta,partes[1]):
            novo_nome = baseact 
        else:
            i=0
            novo_nome="{}_{}".format(mun,etiqueta)
            for p in partes:
                if re.match('\D',p):
                    pass 
                else:
                    novo_nome=novo_nome+'_'+p 
        return novo_nome

    def _proc_fotos(self,res_cons,cons,etiqueta):
        con_pg=None
        cur_pg=None
        result=True
        conftp=ConfFTP()
        res=conftp.conectar()
        if not res:
            return False
        con_pg=ConnBD()
        try:
            for f in res_cons:
                nome_arquivo=os.path.basename(f[1])
                #TODO: ELEMENTOS SEN CODIGO CONCELLO
                cod_concello=f[0]
                if cod_concello is None:
                    cod_concello=00000
                novo_nome=self._format_nome(etiqueta,nome_arquivo,cod_concello)
                # ruta_windows=pathlib.PureWindowsPath(f[1])
                rel_win=pathlib.PureWindowsPath(f[1])
                ruta_antiga= os.path.join(self.carpeta_base_qfield,rel_win)
                # self.log.info("Antiga {}".format(ruta_antiga))
                # print(ruta_antiga)
                ruta_nova=os.path.join(self.carpeta_lect_proxecto,novo_nome)
                self.log.info("Nova : {} ".format(ruta_nova))
                resize_image(ruta_antiga,ruta_nova)    
                relativa_nova=os.path.relpath(ruta_nova,self.carpeta_base)
                # url=Config_Querys.SERVIDOR + novo_nome
                url=Config_Querys.SERVIDOR + novo_nome
                quer_updt=cons.format(relativa_nova,url,f[-1])
                cur_pg=con_pg.get_cursor()
                cur_pg.execute(quer_updt)
                if cur_pg.rowcount > 0 :
                    con_pg.conn.commit()
                    self.log.ok("Foto copiada : {}".format(ruta_nova))
                    cur_pg.close()
                    res=conftp.sube_arquivo(ruta_nova,novo_nome)
                    del self.fotos_campo[ruta_antiga]
                    self.numero_fotos=self.numero_fotos-1
                else:
                    con_pg.conn.rollback()
                    self.log.ko("Probablemente erro na actualizacion")
                    self.log.ko(quer_updt)
                    cur_pg.close()
                    
                    # if not res:
                    #     QgsMessageLog.logMessage("Non se puido enviar o servidor a foto {}".format(ruta_nova), "Fotos", level=Qgis.Critical)
        except Exception as e:
            self.log.ko("{}".format(e))
            result=False
            raise
        finally:
            conftp.pecha_conexion()
            if con_pg:
                ConnBD.pecha_conexion()
            if cur_pg:
                cur_pg.close()
        return result

    def fotos_edar(self):
        qu="""
            update datos_psg.edarpsfotos set ruta='{}' , url='{}' where uuid='{}'
        """
        res=self._proc_fotos(self.res_edar,qu,Config_Querys.ed)
        return res 
    def fotos_bombeos(self):
        qu="""
            update datos_psg.bombpsfoto set ruta='{}' , url='{}' where uuid='{}'
        """
        res=self._proc_fotos(self.res_bomb,qu,Config_Querys.bb)
        return res 
    def fotos_ttorm(self):
        qu="""
            update datos_psg.ttormpsfoto set ruta='{}', url='{}' where uuid='{}'
        """
        res=self._proc_fotos(self.res_ttorm,qu,Config_Querys.ttorm)
        return res 
    def fotos_munips(self):
        qu="""
            update datos_psg.munipsfotos set ruta='{}' , url='{}' where uuid='{}'
        """
        res=self._proc_fotos(self.res_mun,qu,Config_Querys.ttorm)
        return res 
    def run(self):
        fot_bomb=self.fotos_bombeos()
        fot_ed=self.fotos_edar()
        fot_tt=self.fotos_ttorm()
        fot_muni=self.fotos_munips()
        num_copiadas= len(self.fotos_campo)
        if num_copiadas>0:
            self.log.coidado(f"Hai fotos sen vincular {len(self.fotos_campo)}")
            for k in self.fotos_campo.keys():
                self.log.coidado(f"{k}")
        return fot_bomb or fot_ed or fot_tt or fot_muni



# fotos=Config_Querys(carpeta_proxecto,carpeta)
# x=fotos.lee_carpeta()
# if x:
#     fotos.log.info("Hai fotos")
#     y=fotos.consultas()
#     if y:
#         fotos.log.info("Facendo consultas")
#         fotos.run()




def completado(exception, result=None):
    if exception is None:
        if result is None:
            QgsMessageLog.logMessage(
                    "Erro non capturado", "FOTOS", Qgis.Info)
            QMessageBox.warning(iface.mainWindow(), "FOTOS", 'Erro non capturado')
        if result['res'] == 0:
            QgsMessageLog.logMessage(
                    "Non hai fotos ou non estan na carpeta DCIM do paquete", "FOTOS", Qgis.Info)
            QMessageBox.warning(iface.mainWindow(), "FOTOS", 'Non hai fotos ou non estan na carpeta DCIM do paquete')
        elif result['res'] == 1:
            QgsMessageLog.logMessage(
                    "Non exiten fotos na carpeta do paquete QFIELD", "FOTOS", Qgis.Info)
            QMessageBox.warning(iface.mainWindow(), "FOTOS",'Non exiten fotos na carpeta do paquete QFIELD')
        elif result['res'] == 2:
            QgsMessageLog.logMessage(
                    "As fotos do paquete estan sen vincular", "FOTOS", Qgis.Info)
            QMessageBox.critical(iface.mainWindow(), "FOTOS", 'As fotos do paquete estan sen vincular')
        elif result['res'] == 3:
            QgsMessageLog.logMessage(
                    "Foton subidas o servidor", "FOTOS", Qgis.Info)
            QMessageBox.information( iface.mainWindow(), "FOTOS", 'Foton subidas o servidor')
        elif result['res'] == 4:
            QgsMessageLog.logMessage(
                    "Foton subidas o servidor,con fotos da carpeta sen vincular", "FOTOS", Qgis.Info)
            QMessageBox.warning(iface.mainWindow(), "FOTOS", 'Foton subidas o servidor,con fotos da carpeta sen vincular')
    else:
        QgsMessageLog.logMessage("Exception: {}".format(
                exception), "FOTOS", Qgis.Critical)
        QMessageBox.critical(iface.mainWindow(),"FOTOS", 'Erro con excepcions')
        raise exception

def qgis_task(task, ruta_proxecto, ruta_c_qfield):
    c = Config_Querys(ruta_proxecto, ruta_c_qfield)
    c.log.savelog(ruta_c_qfield)
    c.log.info("INICIA")
    lect = c.lee_carpeta()
    try:
        if lect:
            cons = c.consultas()
            if cons:
                proc = c.run()
                if proc:
                    c.log.pecha()
                    if c.numero_fotos>0:
                        return {'res': 4}
                    else:
                        return {'res': 3}
                else:
                    c.log.pecha()
                    return {'res': 2}
            else:
                c.log.pecha()
                return {'res': 1}
        else:
            c.log.pecha()
            return {'res': 0}
    finally:
        c.log.pecha()
def sincroniza_fotos():
    carpeta=DialogoCarpeta().abre_carpeta()
    carpeta_proxecto=Proxecto().carpeta_proxecto()
    if not carpeta:
        return
    carpeta=str(pathlib.PurePath(carpeta).parent)
    tar=QgsTask.fromFunction(u'Sincro fotos',qgis_task,on_finished=completado,ruta_proxecto=carpeta_proxecto,ruta_c_qfield=carpeta)
    QgsApplication.taskManager().addTask(tar)


def sincroniza_sincro():
    carpeta=DialogoCarpeta().abre_carpeta()
    carpeta_proxecto=Proxecto().carpeta_proxecto()
    if not carpeta:
        return
    carpeta=pathlib.PurePath(carpeta).parent
    fotos=Config_Querys(carpeta_proxecto,carpeta)
    fotos.log.savelog(carpeta)
    x=fotos.lee_carpeta()
    if x:
        fotos.log.info("Hai fotos")
        y=fotos.consultas()
        if y:
            fotos.log.info("Facendo consultas")
            fotos.run()
            fotos.log.pecha()
        else:
            fotos.log.pecha() 
    else:
        fotos.log.pecha()
# if __name__ == "__main__":
#     # sincroniza_sincro()
# sincroniza_fotos()


# project = QgsProject.instance()
# QgsExpressionContextUtils.setProjectVariable(project,'ftp_user','psg')
# QgsExpressionContextUtils.setProjectVariable(project,'ftp_pass','pl4ns4ng4l')

# <script>document.write(expression.evaluate("'<div>Image: <img src = \"'ftp://||@ftp_user||:||@ftp_pass||@158.69.250.93/||url||'\"  width=\"300\" height=\"225\" alt=\"Alias Name\"/></div>'"));</script>
if __name__ == "__main__":
    sincroniza_sincro()
    # carpeta=DialogoCarpeta().abre_carpeta()
    # carpeta_proxecto=Proxecto().carpeta_proxecto()
    # if carpeta:

    #     carpeta=str(pathlib.PurePath(carpeta).parent)
    #     tar=QgsTask.fromFunction(u'Sincro fotos',qgis_task,on_finished=completado,ruta_proxecto=carpeta_proxecto,ruta_c_qfield=carpeta)
    #     QgsApplication.taskManager().addTask(tar)


# <script>document.write(expression.evaluate("'<div>Image: <img src = \"||url||\"  width=\"300\" height=\"225\" alt=\"Alias Name\"/></div>'"));</script>