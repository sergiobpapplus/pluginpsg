from .util.utiles import Mensaxe,LogQgis
from qgis.utils import iface
from qgis.PyQt.QtWidgets import *
from qgis.core import *
import uuid

from .capas import EDAR,Conexions,Nucleo

def conecta_100():
    conecta(100)
def conecta_75():
    conecta(75)
def conecta_50():
    conecta(50)
def conecta_33():
    conecta(33)
def conecta_25():
    conecta(25)
def conecta_0():
    conecta(0)
log=LogQgis("Conexions")
mensaxe=Mensaxe("Conexions")

def edita_conexion(porc):
    conexions=Conexions().capa
    conexions.startEditing()
    for f in conexions.selectedFeatures():
        f['porcconn']=porc
        conexions.updateFeature(f)
    conexions.commitChanges()
    mensaxe.ok("Conexions actualizadas")
    conexions.removeSelection()

def crea_conexion(porc):
    edar=EDAR().capa
    num_edar=0
    log.info(f"{num_edar}")
    ed=None
    for f in edar.selectedFeatures():
        ed=f
        num_edar=num_edar+1
    log.info(f"{num_edar}")
    if num_edar<1:
        mensaxe.ko("Non hai edar seleccionada")
        return
    elif num_edar>1:
        mensaxe.ko("Hai varias edar seleccionadas")
        return
    eduid=ed['uuid']
    edxeom=ed.geometry().asPoint()
    layer = Nucleo().capa
    num_nucleos=0
    for f in layer.selectedFeatures():
        num_nucleos+=1
    if num_nucleos<1:
        mensaxe.ko("Non hai nucleos seleccinados")
        return
    conexions=Conexions().capa
    if eduid:
        conexions.startEditing()
        for f in layer.selectedFeatures():
            feat = QgsFeature(conexions.fields())
            feat['fkedaruuid']=eduid
            feat['fkuuidnucleo']=f['uuid']
            feat['porcconn']=porc
            feat['uuid']=f"{uuid.uuid1()}"
            xeom=QgsGeometry.fromPolylineXY([edxeom, f.geometry().asPoint()])
            feat.setGeometry(xeom)
            conexions.addFeature(feat)
        conexions.commitChanges()
    mensaxe.ok("Conexions creadas")
    layer.removeSelection()
def conecta(porc):
    """
    Crea conexions (o 100%) entre os elementos da capa núcleos seleccionados e a EDAR seleccionada 
    NON GARDA OS CAMBIOS, HAI QUE CONFIRMALOS NA CAPA CONEXIONS 
    """
    conexions=Conexions().capa
    sel=0
    for f in conexions.selectedFeatures():
        sel+=1
    if sel > 0:
        edita_conexion(porc)
    else:
        crea_conexion(porc)