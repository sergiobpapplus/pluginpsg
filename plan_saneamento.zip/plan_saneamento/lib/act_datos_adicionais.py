from typing import Dict, List
from openpyxl import Workbook,load_workbook

from .dto_excel import EDARDTO,BOMBDTO,TTORMDTO
from .util.utiles import Proxecto,LogQgis
from .util.con_bd import ConnBD
import re 
import os
from qgis.PyQt.QtWidgets import QFileDialog
from qgis.utils import iface
import urllib 
import json 


import os
import pathlib



class DialogoExcel:
    last_folder=None 
    def abre_dialogo(self,msg,ext):
        if DialogoExcel.last_folder and os.path.exists(DialogoExcel.last_folder):
            carpeta=DialogoExcel.last_folder 
        else:
           carpeta=Proxecto().carpeta

        filename = QFileDialog.getOpenFileName(iface.mapCanvas(), msg,carpeta, ext)
        carp=str(pathlib.PurePath(filename[0]).parent)
        DialogoExcel.last_folder=carp
        return filename[0]
    def abre_gpkg(self,msg):
        return self.abre_dialogo(msg,'data.gpkg')
        
    def abre_excel(self,msg):
        return self.abre_dialogo(msg,'*.xlsx')
        




def clear_parroquia(text):
    rgx='[\(\[].*?[\)\]]'
    texto=re.sub(rgx,'',text)
    return texto



class Elemento:
    plantilla:Workbook=None
    def __init__(self,concello,log) -> None:
        self.concello=concello 
        self.log:LogQgis=log
    def query_ex(self):
        conn=ConnBD()
        try:
            cur_pg=conn.get_cursor()
            cur_pg.execute(self.cons_ex)
            self.ls_datos=cur_pg.fetchall()
        except:
            if cur_pg:
                cur_pg.close
            ConnBD.pecha_conexion()
    def escribe_folla(self):
        self.sheet=Elemento.plantilla[self.nome_folla]
        self.taboa_excel=self.sheet.tables[self.nome_taboa]
        conn=ConnBD()
        cur_pg=conn.get_cursor()
        try:
            cur_pg.execute(self.cons_ex)
            self.elementos_concello=cur_pg.fetchall()
            cur_pg.close()

        finally:
            if cur_pg:
                cur_pg.close()
            ConnBD.pecha_conexion()
    def lee_folla(self):
        try:
            self.sheet=Elemento.plantilla[self.nome_folla]
        except:
            self.sheet=None 
        if self.sheet:
            self.taboa_excel=self.sheet.tables[self.nome_taboa]
        else:
            self.taboa_excel=None 

    def elimina_folla(self):
        Elemento.plantilla.remove_sheet(self.sheet)


str_chk_cod="""
select count(*) from datos_psg.edarps where codedar={} group by codedar
"""



class ExcelEDAR(Elemento):
    def __init__(self,concello,log) -> None:
        super().__init__(concello, log)
        self.nome_folla='EDAR'
        self.nome_taboa='edarps'
        self.ls_elementos=[]
    def lee_folla(self):
        super().lee_folla()
        if self.sheet:
            try:
                conn=ConnBD()
                rw_nm=0
                for row in self.sheet.rows:
                    if rw_nm > 4:
                        print('Fila')
                        self.ls_elementos.append(EDARDTO(row,self.log))
                    rw_nm+=1
                for e in self.ls_elementos:
                    e.update_safe(conn)
            finally:
                ConnBD.pecha_conexion()
        else:
            self.log.coidado("Non hai datos de EDAR")

class ExcelBOMBEO(Elemento):

    def __init__(self,concello,log) -> None:
        super().__init__(concello, log)
        self.nome_folla='BOMBEOS'
        self.nome_taboa='bombps'
        self.ls_elementos=[]
    def lee_folla(self):
        super().lee_folla()
        if self.sheet:
            try:
                conn=ConnBD()
                rw_nm=0
                for row in self.sheet.rows:
                    if rw_nm > 4:
                        self.ls_elementos.append(BOMBDTO(row,self.log))
                    rw_nm+=1
                for e in self.ls_elementos:
                    e.update_safe(conn)
            finally:
                ConnBD.pecha_conexion()
        else:
            self.log.coidado("Non hai datos de EDAR")



class ExcelTTorm(Elemento):

    def __init__(self,concello,log) -> None:
        super().__init__(concello, log)
        self.nome_folla='TANQUES_TORMENTA'
        self.nome_taboa='ttormps'
        self.ls_elementos=[]
    def lee_folla(self):
        super().lee_folla()
        if self.sheet:
            rw_nm=0
            for row in self.sheet.rows:
                if rw_nm > 3:
                    self.ls_elementos.append(TTORMDTO(row,self.log))
                rw_nm+=1
            for e in self.ls_elementos:
                self.log.info(str(e.get_dict()))
        else:
            self.log.coidado("Non hai datos de EDAR")


def read_excel():
    dialog=DialogoExcel()
    # arq=dialog.abre_excel("Abre excel")
    arq=r"C:\Users\sergio.botana\OneDrive - ApplusGlobal\PSG\VISITAS\SOL_DATOS_ADICIONAIS\MODIFICADOS\15002_Ames.xlsx"

    wbook=load_workbook(arq)
    Elemento.plantilla=wbook
    log=LogQgis("Plantilla de excel")
    codine=Proxecto().get_variable('concello')
    edar=ExcelEDAR(codine,log)
    edar.lee_folla()
    bombeo=ExcelBOMBEO(codine,log)
    bombeo.lee_folla()
    # ttorm=ExcelTTorm(codine,log)
    # ttorm.lee_folla()
    # edar.escribe_folla()
    # bombeos=ExcelBombeo(codine,log)
    # bombeos.escribe_folla()
    # tt=ExcelTanques(codine,log)
    # tt.escribe_folla()
    # nome_conc=get_nom_concello(codine)
    # nome_excel=f"{codine}_{nome_conc[0]}_datos adicionais.xlsx"
    # wbook.save(os.path.join(ruta_prox,nome_excel))

# codifica()
# write_excel()
# iface.messageBar().pushMessage("Excel datos adicionais", "Excel xerado", level=Qgis.Success)

# import subprocess
# subprocess.check_call(['python', '-m', 'pip', 'install', 'xlwings'])