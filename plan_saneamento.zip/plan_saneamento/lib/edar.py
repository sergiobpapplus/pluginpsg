from qgis.utils import iface
from qgis.PyQt.QtWidgets import *
from qgis.core import *
from .util.wrapper_qgis import lee_capa_emb
"""
Seleccionadas 2 EDAR, 1 orixe concello (borde vermello) 1 orixe SISBAGAL
Despraza SISBAGAL e engade o nome do concello , borra a do concello
"""



def renombra_e_move(move):
    layer = lee_capa_emb('edarps')
    count=0
    sisb=None
    other=None
    for f in layer.selectedFeatures():
        if f['int_origendato']==2:
            sisb=f
            count=count+1
        else:
            other=f
            count=count+1
    if count>2:
        iface.messageBar().pushMessage("EDAR", "Selección incorrecta", level=Qgis.Warning)
        return
    else:
        layer.startEditing()
        sisb['nombre']=other['nombre']
        if move:
            sisb.setGeometry(other.geometry())
        other['int_borra']=1
        layer.updateFeature(sisb)
        layer.updateFeature(other)
        layer.commitChanges()
        iface.messageBar().pushMessage("EDAR", "Renombrado", level=Qgis.Success)

def renombra():
    renombra_e_move(False)
def move():
    renombra_e_move(True)
def revisar():
    layer = lee_capa_emb('edarps')
    layer.startEditing()
    for f in layer.selectedFeatures():
        f['int_revisar_id']=1
        layer.updateFeature(f)
    layer.commitChanges()

